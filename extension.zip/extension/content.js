/**
 * Content Script - Extraction données produit depuis 1688, AliExpress et Alibaba
 * v2.0 — Images classées, vidéos, description structurée, variantes enrichies
 */

(function() {
  'use strict';

  if (window.itVisionScraperInjected) return;
  window.itVisionScraperInjected = true;

  console.log('[IT Vision v2] Scraper actif sur', window.location.hostname);

  // ==========================================
  // UTILITAIRES PARTAGÉS
  // ==========================================

  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  const trySelectors = (selectors) => {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el?.textContent?.trim()) return el.textContent.trim();
    }
    return null;
  };

  /** Scroll progressif pour déclencher le lazy-load */
  const deepScroll = async (maxY = 6000, step = 400, delay = 250) => {
    for (let y = 0; y <= maxY; y += step) {
      window.scrollTo(0, y);
      await wait(delay);
    }
    window.scrollTo(0, 0);
    await wait(300);
  };

  /** CDN d'images produit (1688, AliExpress, Alibaba) */
  const PRODUCT_CDN_HOST_RE = /(?:^|\.)(?:alicdn\.com|aliexpress-media\.com|aliexpress\.com|alibaba\.com|1688\.com|alibabausercontent\.com)$/i;

  /**
   * URL d'image canonique en pleine résolution : https, sans suffixe de redimensionnement
   * (xxx.jpg_220x220q75.jpg_.avif, xxx.310x310.jpg, xxx.summ.jpg…), sans paramètres.
   * Deux tailles d'une même image donnent la même URL, ce qui sert aussi au dédoublonnage.
   */
  const cleanImageUrl = (src) => {
    if (!src || typeof src !== 'string') return '';
    let url = src.trim().replace(/\\u002F/gi, '/').replace(/\\\//g, '/');
    if (url.startsWith('//')) url = 'https:' + url;
    if (!/^https?:\/\//i.test(url)) return '';
    let parsed;
    try { parsed = new URL(url); } catch { return ''; }
    if (!PRODUCT_CDN_HOST_RE.test(parsed.hostname)) return parsed.href.split('#')[0];
    const base = parsed.pathname.match(/^(.*?\.(?:jpe?g|png|webp))(?=[_.]|$)/i);
    const path = (base ? base[1] : parsed.pathname)
      .replace(/\.(?:\d{2,4}x\d{2,4}|summ|search|sum)\.(jpe?g|png|webp)$/i, '.$1');
    return `https://${parsed.hostname}${path}`;
  };

  /** Hébergeurs qui ne servent jamais de photos produit */
  const NOISE_HOST_RE = /(?:^|\.)(?:paypal|klarna|afterpay|clearpay|stripe|sezzle|affirm|googletagmanager|google-analytics|doubleclick|facebook|fbcdn)\.(?:com|net)$/i;

  /** Mots qui, dans le CHEMIN d'une image, signalent un élément d'interface */
  const NOISE_PATH_TOKENS = new Set([
    'logo', 'logos', 'banner', 'banners', 'icon', 'icons', 'badge', 'badges', 'qrcode', 'qr', 'avatar', 'avatars',
    'coupon', 'coupons', 'promo', 'promotion', 'paypal', 'visa', 'mastercard', 'amex', 'klarna', 'afterpay',
    'watermark', 'sprite', 'sprites', 'placeholder', 'loading', 'loader', 'spinner', 'pixel', 'tracking', 'tracker',
    'beacon', 'flag', 'flags', 'emoji', 'favicon', 'blank', 'transparent', 'spacer', 'nopic', 'noimage',
  ]);

  /**
   * Image d'interface (logo, icône, paiement, suivi…) plutôt que photo produit.
   * Les mots-clés sont comparés mot à mot, sur le chemin seulement : les noms de fichiers
   * des CDN sont des identifiants aléatoires qui contiennent souvent « cb », « ria », « eps »…
   * et l'hôte cbu01.alicdn.com héberge justement les photos 1688.
   */
  const isNoiseImage = (url) => {
    if (!url || typeof url !== 'string') return true;
    const value = url.trim();
    if (/^data:/i.test(value)) return true;
    let parsed;
    try { parsed = new URL(value.startsWith('//') ? 'https:' + value : value); } catch { return true; }
    if (NOISE_HOST_RE.test(parsed.hostname)) return true;
    const path = parsed.pathname.toLowerCase();
    if (/\.(?:svg|gif|ico)$/.test(path)) return true;
    return path.split(/[^a-z0-9]+/).some(token => NOISE_PATH_TOKENS.has(token));
  };

  /** Miniature d'une vraie photo produit (xxx.jpg_80x80.jpg) : petite à l'écran, mais à garder */
  const isProductThumbnail = (src) => {
    if (!src) return false;
    try {
      const parsed = new URL(src.startsWith('//') ? 'https:' + src : src);
      return PRODUCT_CDN_HOST_RE.test(parsed.hostname) && /\.(?:jpe?g|png|webp)[_.]\d{2,4}x\d{2,4}/i.test(parsed.pathname);
    } catch { return false; }
  };

  /** Filtrer une image par ses attributs DOM (alt, class, taille, parent) */
  const isNoiseImageElement = (img) => {
    if (!img) return true;
    const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-original') || img.getAttribute('data-lazy-src') || '';
    if (isNoiseImage(src)) return true;

    // Alt text
    const alt = (img.getAttribute('alt') || '').toLowerCase();
    if (/(klarna|afterpay|paypal|visa|mastercard|payment|logo|badge|icon|trust|secure|guarantee|buyer.?protection|qrcode|qr.?code|wechat|whatsapp|promo|coupon|sale|discount|banner|advertisement)/i.test(alt)) return true;

    // Class / ID
    const cls = (img.className || '').toLowerCase();
    const id = (img.id || '').toLowerCase();
    const combined = `${cls} ${id}`;
    if (/(payment|logo|badge|icon|trust|secure|promo|coupon|banner|qrcode|review|avatar|profile|advertisement|sponsored|widget|popup|toast|placeholder)/i.test(combined)) return true;

    // Parent suspect
    let parent = img.parentElement;
    for (let i = 0; i < 4 && parent; i++) {
      const pCls = (parent.className || '').toLowerCase();
      const pId = (parent.id || '').toLowerCase();
      if (/(payment|logo|badge|banner|promo|coupon|review|recommend|seller|store|advertisement|sponsored|widget|popup|toast|trust|secure)/i.test(`${pCls} ${pId}`)) {
        return true;
      }
      parent = parent.parentElement;
    }

    // Taille trop petite = icône (sauf miniature d'une photo produit : la galerie en est faite)
    const thumbnail = isProductThumbnail(src);
    const w = img.naturalWidth || parseInt(img.getAttribute('width') || '0');
    const h = img.naturalHeight || parseInt(img.getAttribute('height') || '0');
    if (!thumbnail && ((w > 0 && w < 100) || (h > 0 && h < 100))) return true;

    // Position suspecte: images absolument positionnées très petites
    const rect = img.getBoundingClientRect();
    if (!thumbnail && rect.width > 0 && rect.height > 0 && (rect.width < 80 || rect.height < 80)) {
      // Vérifier si c'est dans une zone de contenu principal ou un coin
      const style = window.getComputedStyle(img);
      if (style.position === 'absolute' || style.position === 'fixed') return true;
    }

    return false;
  };

  /** Extraire toutes les vidéos d'une zone DOM */
  const extractVideos = (root) => {
    const videos = new Set();
    if (!root) root = document;

    // <video> tags
    root.querySelectorAll('video').forEach(v => {
      const src = v.getAttribute('src') || v.querySelector('source')?.getAttribute('src');
      if (src && src.startsWith('http')) videos.add(src);
      // poster = image de preview vidéo
      const poster = v.getAttribute('poster');
      if (poster) videos.add('poster:' + poster);
    });

    // data-video-url (fréquent sur 1688 et AliExpress)
    root.querySelectorAll('[data-video-url], [data-video-src], [data-video]').forEach(el => {
      const url = el.getAttribute('data-video-url') || el.getAttribute('data-video-src') || el.getAttribute('data-video');
      if (url && url.startsWith('http')) videos.add(url);
    });

    // Scripts JSON contenant des URLs vidéo
    root.querySelectorAll('script:not([src])').forEach(s => {
      const txt = s.textContent || '';
      // Pattern: "videoUrl":"https://..."
      const matches = txt.matchAll(/"(?:video[Uu]rl|videoSrc|videoPath|video_url)"\s*:\s*"(https?:\/\/[^"]+)"/g);
      for (const m of matches) {
        if (m[1] && !m[1].includes('thumbnail')) videos.add(m[1]);
      }
    });

    // Éléments avec background vidéo ou liens .mp4
    root.querySelectorAll('a[href$=".mp4"], a[href*="video"]').forEach(a => {
      const href = a.getAttribute('href');
      if (href && href.startsWith('http')) videos.add(href);
    });

    return Array.from(videos).filter(v => !v.startsWith('poster:'));
  };

  /** Extraire posters de vidéos */
  const extractVideoPosters = (root) => {
    const posters = [];
    if (!root) root = document;
    root.querySelectorAll('video[poster]').forEach(v => {
      const p = v.getAttribute('poster');
      if (p && p.startsWith('http')) posters.push(cleanImageUrl(p));
    });
    return posters;
  };

  /** Vérifie qu'une URL est hébergée sur un CDN produit 1688/AliExpress */
  const is1688ProductImage = (src) => /cbu\d*\.alicdn\.com|img\.alicdn\.com|sc\d+\.alicdn\.com|imgextra|gw\.alicdn\.com|\.1688\.com/i.test(src);

  const isAliProductImage = (src) => /ae\d+\.alicdn\.com|aliexpress-media\.com|cbu\d*\.alicdn\.com|img\.aliexpress|sc\d+\.alicdn\.com|assets\.alicdn\.com\/imgextra|img\.alicdn\.com|imgextra|gw\.alicdn\.com/i.test(src);

  const isAlibabaProductImage = (src) => /s\.alicdn\.com\/@sc\d+|sc\d+\.alicdn\.com|alibaba\.com|img\.alicdn\.com|imgextra|alibabausercontent\.com/i.test(src);

  const isProductImageUrl = (src) => /^https?:\/\//i.test(src) && !isNoiseImage(src) && (is1688ProductImage(src) || isAliProductImage(src) || isAlibabaProductImage(src));

  /** Déduplication d'images par URL normalisée */
  const deduplicateImages = (urls) => {
    const seen = new Set();
    return urls.filter(url => {
      if (isNoiseImage(url)) return false;
      const clean = cleanImageUrl(url);
      if (!clean) return false;
      let key = clean;
      try {
        const parsed = new URL(clean);
        key = `${parsed.hostname}${parsed.pathname}`.replace(/_\d+x\d+[^.]*/i, '');
      } catch {
        key = clean.split('?')[0];
      }
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  };

  // ==========================================
  // IMAGES DEPUIS LES DONNÉES DE LA PAGE (JSON intégré)
  // ==========================================
  // Les pages produit embarquent la liste officielle des images (galerie, SKU, description)
  // dans des scripts JSON : plus fiable que le DOM, qui ne montre que ce qui est chargé à l'écran.

  const IMAGE_VALUE_RE = /^(?:https?:)?\/\/[^\s"'<>]+\.(?:jpe?g|png|webp)(?:[_.?#][^\s"'<>]*)?$/i;
  // Vidéos produit : fichiers vidéo ou lecteurs des plateformes (cloud.video.taobao.com/play/…)
  const VIDEO_VALUE_RE = /^(?:https?:)?\/\/(?:[^\s"'<>]+\.(?:mp4|webm|m3u8|mov)(?:[?#][^\s"'<>]*)?|(?:cloud\.video\.taobao\.com|video\.aliexpress-media\.com|cloud\.video\.alibaba\.com)\/play\/[^\s"'<>]+)$/i;
  // Zones de la page qui ne décrivent pas ce produit (recommandations, boutique, avis, pubs…)
  const FOREIGN_PATH_RE = /recommend|similar|related|crosssell|cross_sell|moreitem|otheritem|bestsell|youmaylike|guess|store|shop(?!ping)|seller|company|supplier|logo|avatar|banner|coupon|promo|review|feedback|evaluation|comment|buyer|footer|header|navigation|\bads?\b|advert|marketing|campaign|activity/;
  const DESCRIPTION_PATH_RE = /desc|detailcontent|detailhtml|detailimage|richtext|introduction|productdetail/;
  const VARIANT_PATH_RE = /sku|saleprop|propvalue|propertyvalue|skuattr|attrvalue|variation|variant|propertyimage/;
  const GALLERY_PATH_RE = /imagepathlist|offerimglist|offerimg|mainimage|mainpic|bigimage|summimage|productimage|imagelist|imglist|piclist|picurl|imageurls|gallery|mediaitems|media|images?(?:\.|$)|pics?(?:\.|$)/;
  const VARIANT_NAME_KEYS = ['propertyValueDisplayName', 'propertyValueName', 'skuPropertyValueTips', 'valueName', 'propValueName', 'name', 'alias', 'text', 'value', 'title'];

  /** Fin d'un littéral JSON/JS équilibré à partir de `start` ({ ou [), chaînes comprises */
  const findBalancedEnd = (text, start) => {
    const open = text[start];
    const close = open === '{' ? '}' : ']';
    let depth = 0;
    for (let i = start; i < text.length; i++) {
      const c = text[i];
      if (c === '"' || c === "'" || c === '`') {
        for (i++; i < text.length && text[i] !== c; i++) if (text[i] === '\\') i++;
        continue;
      }
      if (c === open) depth++;
      else if (c === close && --depth === 0) return i + 1;
    }
    return -1;
  };

  /** Parse le littéral ; s'il n'est pas du JSON strict ({ data: {...} }), descend d'un niveau */
  const parseJsonLiteral = (text, start, end, roots, depth = 0) => {
    const chunk = text.slice(start, end);
    try { roots.push(JSON.parse(chunk)); return; } catch {}
    if (depth >= 2) return;
    const re = /[:=(]\s*([{[])/g;
    re.lastIndex = 1;
    let m;
    while ((m = re.exec(chunk))) {
      const childStart = m.index + m[0].length - 1;
      const childEnd = findBalancedEnd(chunk, childStart);
      if (childEnd <= childStart) break;
      if (childEnd - childStart > 30) parseJsonLiteral(chunk, childStart, childEnd, roots, depth + 1);
      re.lastIndex = childEnd;
    }
  };

  /** Objets JSON intégrés à la page : JSON-LD, data islands, états d'hydratation (window.x = {...}) */
  const collectPageJson = () => {
    const roots = [];
    document.querySelectorAll('script:not([src])').forEach(script => {
      const text = script.textContent || '';
      if (text.length < 40 || text.length > 8_000_000) return;
      if (!/\.(?:jpe?g|png|webp|mp4)|"width"/i.test(text)) return;
      if ((script.getAttribute('type') || '').toLowerCase().includes('json')) {
        try { roots.push(JSON.parse(text)); return; } catch {}
      }
      const re = /[=(]\s*([{[])/g;
      let m, guard = 0;
      while ((m = re.exec(text)) && guard++ < 300) {
        const start = m.index + m[0].length - 1;
        const end = findBalancedEnd(text, start);
        if (end <= start) continue;
        if (end - start > 30 && /\.(?:jpe?g|png|webp|mp4)/i.test(text.slice(start, end))) parseJsonLiteral(text, start, end, roots);
        re.lastIndex = end;
      }
    });
    return roots;
  };

  const normalizeVariantName = (name) => String(name || '').toLowerCase().replace(/\s+/g, ' ').trim();

  /** Images de la page classées d'après le chemin des clés JSON qui les contiennent */
  const harvestPageImages = () => {
    const out = { gallery: [], description: [], variant: [], variantByName: {}, videos: [] };
    const add = (list, url) => { if (url && !list.includes(url)) list.push(url); };
    let visited = 0;

    // Une URL d'image trouvée au chemin `path` (clés JSON depuis la racine)
    const visitImage = (raw, path) => {
      const value = raw.trim();
      if (VIDEO_VALUE_RE.test(value)) {
        if (!FOREIGN_PATH_RE.test(path.join('.').toLowerCase())) add(out.videos, value.startsWith('//') ? 'https:' + value : value);
        return '';
      }
      if (!IMAGE_VALUE_RE.test(value)) return '';
      const joined = path.join('.').toLowerCase();
      if (FOREIGN_PATH_RE.test(joined)) return '';
      const url = cleanImageUrl(raw);
      if (!url || isNoiseImage(url)) return '';
      if (DESCRIPTION_PATH_RE.test(joined)) add(out.description, url);
      else if (VARIANT_PATH_RE.test(joined)) { add(out.variant, url); return url; }
      else if (GALLERY_PATH_RE.test(joined)) add(out.gallery, url);
      return '';
    };

    const walk = (node, keys, depth) => {
      if (!node || depth > 16 || ++visited > 300000) return;
      if (Array.isArray(node)) {
        node.forEach((child, i) => {
          if (typeof child === 'string') visitImage(child, keys.concat(String(i)));
          else walk(child, keys.concat(String(i)), depth + 1);
        });
        return;
      }
      if (typeof node !== 'object') return;

      let ownImage = '';
      for (const [key, value] of Object.entries(node)) {
        const path = keys.concat(key);
        if (typeof value === 'string') {
          const variantImage = visitImage(value, path);
          if (!ownImage) ownImage = variantImage;
        } else if (value && typeof value === 'object') {
          walk(value, path, depth + 1);
        }
      }

      // Valeur de SKU : associer son image à son libellé (« Noir », « 128 Go »…)
      if (ownImage) {
        const nameKey = VARIANT_NAME_KEYS.find(k => typeof node[k] === 'string' && node[k].trim() && !IMAGE_VALUE_RE.test(node[k].trim()));
        if (nameKey) out.variantByName[normalizeVariantName(node[nameKey])] = ownImage;
      }
    };

    collectPageJson().forEach(root => walk(root, [], 0));
    return out;
  };

  /**
   * Classement final des images, commun à toutes les plateformes :
   * - galerie : liste officielle de la page en priorité (dans son ordre), sinon ce que le DOM a trouvé ;
   * - variantes : image de chaque option (complétée par son libellé si le DOM ne l'avait pas) ;
   * - description : images du descriptif, jamais mélangées à la galerie ;
   * - jamais de produit sans image si la page en contient au moins une.
   */
  const finalizeImages = (data) => {
    let page = { gallery: [], description: [], variant: [], variantByName: {}, videos: [] };
    try { page = harvestPageImages(); } catch (e) { console.warn('[IT Vision] Données JSON de la page:', e); }

    // Vidéos : DOM + JSON, uniquement de vraies URL vidéo (pas les liens « vidéo » de navigation)
    data.videos = [...new Set([...(data.videos || []), ...(page.videos || [])]
      .map(v => String(v || '').trim().replace(/^\/\//, 'https://'))
      .filter(v => VIDEO_VALUE_RE.test(v)))].slice(0, 3);

    const unique = (list) => {
      const seen = new Set();
      return (list || []).map(cleanImageUrl).filter(url => url && !isNoiseImage(url) && !seen.has(url) && seen.add(url));
    };

    const domGallery = unique(data.gallery);
    const description = unique([...page.description, ...(data.descriptionImages || []), ...(data.imageCategories?.description || [])]);
    const descriptionSet = new Set(description);

    // Avec une galerie officielle suffisante, le DOM n'apporte que du bruit potentiel
    let gallery = page.gallery.length >= 3
      ? unique(page.gallery)
      : unique([...page.gallery, ...domGallery.filter(url => !descriptionSet.has(url))]);

    (data.variantGroups || []).forEach(group => (group.variants || []).forEach(variant => {
      const own = variant.image ? cleanImageUrl(variant.image) : '';
      variant.image = (own && !isNoiseImage(own) ? own : '') || page.variantByName[normalizeVariantName(variant.name)] || undefined;
    }));
    const variantImages = unique([
      ...(data.variantGroups || []).flatMap(group => (group.variants || []).map(v => v.image)),
      ...page.variant,
    ]);

    if (gallery.length === 0) gallery = variantImages.slice(0, 10);
    if (gallery.length === 0) gallery = description.slice(0, 5);
    if (gallery.length === 0) {
      const og = cleanImageUrl(document.querySelector('meta[property="og:image"]')?.getAttribute('content') || '');
      if (og && !isNoiseImage(og)) gallery = [og];
    }

    const gallerySet = new Set(gallery);
    data.gallery = gallery.slice(0, 20);
    data.image = data.gallery[0] || undefined;
    data.descriptionImages = description.filter(url => !gallerySet.has(url)).slice(0, 30);
    data.imageCategories = {
      main: data.gallery.slice(0, 1),
      gallery: data.gallery,
      variant: variantImages.slice(0, 30),
      description: data.descriptionImages,
      packaging: unique(data.imageCategories?.packaging).slice(0, 5),
    };
    console.log('[IT Vision] Images finales:', {
      galerie: data.gallery.length,
      variantes: variantImages.length,
      description: data.descriptionImages.length,
      sourcePage: page.gallery.length,
    });
    return data;
  };

  // ==========================================
  // COLIS : DIMENSIONS ET POIDS (commun aux trois plateformes)
  // ==========================================

  const toPositive = (value) => {
    const n = typeof value === 'number' ? value : parseFloat(String(value ?? '').replace(',', '.'));
    return Number.isFinite(n) && n > 0 ? n : 0;
  };

  /** Dimensions plausibles d'un colis (cm) : rejette les identifiants et les valeurs absurdes */
  const plausibleDims = (l, w, h) => [l, w, h].every(v => v > 0 && v <= 300);

  /** 1) Données JSON de la page : objet portant longueur + largeur + hauteur (1688 : pieceWeightScale, Alibaba : packaging) */
  const packageFromJson = () => {
    const pick = (obj, names) => {
      for (const [key, value] of Object.entries(obj)) {
        if (names.test(key)) { const n = toPositive(value); if (n) return n; }
      }
      return 0;
    };
    let found = null;
    let visited = 0;
    const walk = (node, depth) => {
      if (found || !node || typeof node !== 'object' || depth > 14 || ++visited > 200000) return;
      if (Array.isArray(node)) { node.forEach(child => walk(child, depth + 1)); return; }
      const l = pick(node, /^(?:package|pkg|packing|piece)?_?len(?:gth)?$/i);
      const w = pick(node, /^(?:package|pkg|packing|piece)?_?wid(?:th)?$/i);
      const h = pick(node, /^(?:package|pkg|packing|piece)?_?(?:hei(?:ght)?|high)$/i);
      if (l && w && h) {
        // Unité éventuellement indiquée à côté : mm → cm
        const unit = String(node.unit || node.lengthUnit || node.sizeUnit || '').toLowerCase();
        const factor = unit === 'mm' ? 0.1 : unit === 'm' ? 100 : 1;
        if (plausibleDims(l * factor, w * factor, h * factor)) {
          const rawWeight = pick(node, /^(?:package|pkg|packing|piece|gross)?_?weight$/i);
          const weightUnit = String(node.weightUnit || '').toLowerCase();
          // 1688 exprime le poids de colis en grammes ; une valeur ≥ 30 sans unité y correspond
          const weightKg = rawWeight ? (weightUnit === 'kg' ? rawWeight : weightUnit === 'g' || rawWeight >= 30 ? rawWeight / 1000 : rawWeight) : 0;
          found = { lengthCm: l * factor, widthCm: w * factor, heightCm: h * factor, weightKg };
          return;
        }
      }
      Object.values(node).forEach(child => walk(child, depth + 1));
    };
    try { collectPageJson().forEach(root => walk(root, 0)); } catch {}
    return found;
  };

  /** 2) Tableau d'emballage à colonnes (1688 : « 长(cm) | 宽(cm) | 高(cm) | 重量(g) ») */
  const packageFromTable = () => {
    const colIndex = (cells, re) => cells.findIndex(c => re.test(c));
    for (const table of document.querySelectorAll('table')) {
      const rows = Array.from(table.querySelectorAll('tr'));
      if (rows.length < 2) continue;
      const head = Array.from(rows[0].querySelectorAll('th, td')).map(c => (c.textContent || '').trim().toLowerCase());
      const li = colIndex(head, /^长|length|longueur/), wi = colIndex(head, /^宽|width|largeur/), hi = colIndex(head, /^高|height|hauteur/);
      if (li < 0 || wi < 0 || hi < 0) continue;
      const factor = /mm/.test(head[li]) ? 0.1 : 1;
      const weightIdx = colIndex(head, /重量|weight|poids/);
      for (const row of rows.slice(1)) {
        const cells = Array.from(row.querySelectorAll('td, th')).map(c => (c.textContent || '').trim());
        const [l, w, h] = [cells[li], cells[wi], cells[hi]].map(v => toPositive(v) * factor);
        if (!plausibleDims(l, w, h)) continue;
        let weightKg = 0;
        if (weightIdx >= 0) {
          const raw = toPositive(cells[weightIdx]);
          weightKg = /\(g\)|（g）|\bg\b|克/.test(head[weightIdx]) && !/kg/.test(head[weightIdx]) ? raw / 1000 : raw;
        }
        return { lengthCm: l, widthCm: w, heightCm: h, weightKg };
      }
    }
    return null;
  };

  /** 3) Texte de la page : « Taille du colis : 20 x 15 x 10 cm », « 包装尺寸：20*15*10cm », « Package size … » */
  const packageFromText = () => {
    const text = (document.body?.innerText || '').slice(0, 200000);
    const label = '(?:包装尺寸|包装规格|外箱尺寸|产品尺寸|尺寸|package\\s*size|packing\\s*size|single\\s*package\\s*size|product\\s*size|dimensions?|taille\\s*(?:du|de\\s*l\'|d\')?\\s*(?:paquet|colis|emballage|produit)[^:：\\n]{0,15}|emballage)';
    const num = '(\\d+(?:[.,]\\d+)?)';
    const sep = '\\s*[x×*✕Xх]\\s*';
    const m = text.match(new RegExp(`${label}[^\\d\\n]{0,25}${num}${sep}${num}${sep}${num}\\s*(mm|cm|m)?\\b`, 'i'));
    if (!m) return null;
    const factor = (m[4] || 'cm').toLowerCase() === 'mm' ? 0.1 : (m[4] || '').toLowerCase() === 'm' ? 100 : 1;
    const [l, w, h] = [m[1], m[2], m[3]].map(v => toPositive(v) * factor);
    return plausibleDims(l, w, h) ? { lengthCm: l, widthCm: w, heightCm: h, weightKg: 0 } : null;
  };

  /** Complète dimensions et poids manquants, toutes plateformes (n'écrase jamais une valeur déjà trouvée) */
  const fillPackageInfo = (data) => {
    const hasDims = toPositive(data.lengthCm) && toPositive(data.widthCm) && toPositive(data.heightCm);
    if (hasDims && toPositive(data.weightKg)) return data;
    const info = packageFromJson() || packageFromTable() || packageFromText();
    if (!info) return data;
    const round = (v) => Math.round(v * 10) / 10;
    if (!hasDims) {
      data.lengthCm = round(info.lengthCm);
      data.widthCm = round(info.widthCm);
      data.heightCm = round(info.heightCm);
    }
    if (!toPositive(data.weightKg) && info.weightKg > 0 && info.weightKg < 500) data.weightKg = Math.round(info.weightKg * 1000) / 1000;
    console.log('[IT Vision] Colis:', { L: data.lengthCm, l: data.widthCm, h: data.heightCm, kg: data.weightKg });
    return data;
  };

  /** Extraire texte propre d'un élément DOM, sans HTML */
  const cleanTextFromElement = (el) => {
    if (!el) return '';
    const clone = el.cloneNode(true);
    // Supprimer les scripts et styles
    clone.querySelectorAll('script, style, noscript, iframe').forEach(n => n.remove());
    return (clone.innerText || clone.textContent || '').trim();
  };

  /** Structurer une description en sections markdown propres */
  const buildStructuredDescription = ({ title, specs, presentationText }) => {
    const parts = [];

    if (title) parts.push(`# ${title}`);

    const specEntries = Object.entries(specs || {}).filter(([k, v]) =>
      k && v && k.length >= 2 && k.length <= 60 && v.length <= 200 &&
      !/^\d+([.,]\d+)?$/.test(k.trim()) &&
      !['n/a', 'non spécifié', 'none'].includes(v.toLowerCase())
    );

    if (specEntries.length > 0) {
      parts.push('\n## Caractéristiques techniques');
      specEntries.slice(0, 25).forEach(([k, v]) => parts.push(`- **${k}**: ${v}`));
    }

    if (presentationText && presentationText.length > 30) {
      const paragraphs = presentationText
        .replace(/\n{3,}/g, '\n\n').replace(/\t/g, ' ')
        .split('\n\n')
        .map(p => p.trim())
        .filter(p => p.length > 15)
        .slice(0, 8);
      if (paragraphs.length > 0) {
        parts.push('\n## Description');
        paragraphs.forEach(p => parts.push(p));
      }
    }

    let desc = parts.join('\n\n');
    if (desc.length > 5000) desc = desc.slice(0, 5000) + '...';
    return desc.trim();
  };

  // ==========================================
  // EXTRACTION DEPUIS L'ETAT JS DE LA PAGE
  // ==========================================

  /** Extraire la valeur d'une assignation window.xxx = {...} dans les scripts inline */
  const extractScriptObject = (varName) => {
    const scripts = document.querySelectorAll('script:not([src])');
    for (const s of scripts) {
      const text = s.textContent || '';
      const idx = text.indexOf(varName);
      if (idx === -1) continue;
      // Cherche le '=' après le nom de variable
      const eq = text.indexOf('=', idx + varName.length);
      if (eq === -1) continue;
      let start = eq + 1;
      while (start < text.length && /\s/.test(text[start])) start++;
      if (start >= text.length) continue;
      const open = text[start];
      if (open !== '{' && open !== '[') continue;
      const close = open === '{' ? '}' : ']';
      let end = start + 1;
      let depth = 1;
      while (end < text.length && depth > 0) {
        const c = text[end];
        if (c === open) depth++;
        else if (c === close) depth--;
        else if (c === '"' || c === "'" || c === '`') {
          const quote = c;
          end++;
          while (end < text.length) {
            const q = text[end];
            if (q === '\\') { end += 2; continue; }
            if (q === quote) { end++; break; }
            end++;
          }
          continue;
        }
        end++;
      }
      if (depth === 0) {
        try { return JSON.parse(text.slice(start, end)); } catch {}
      }
    }
    return null;
  };

  /** Valeur JSON (objet/tableau) qui suit une clé `"key":` dans n'importe quel script inline. */
  const extractJsonAfterKey = (key) => {
    const needle = `"${key}"`;
    for (const s of document.querySelectorAll('script:not([src])')) {
      const text = s.textContent || '';
      let from = 0;
      while (true) {
        const idx = text.indexOf(needle, from);
        if (idx === -1) break;
        from = idx + needle.length;
        let start = text.indexOf(':', from);
        if (start === -1) break;
        start++;
        while (start < text.length && /\s/.test(text[start])) start++;
        const open = text[start];
        if (open !== '{' && open !== '[') continue;
        const close = open === '{' ? '}' : ']';
        let end = start + 1, depth = 1;
        while (end < text.length && depth > 0) {
          const c = text[end];
          if (c === '"') {
            end++;
            while (end < text.length && text[end] !== '"') end += text[end] === '\\' ? 2 : 1;
          } else if (c === open) depth++;
          else if (c === close) depth--;
          end++;
        }
        if (depth === 0) {
          try { return JSON.parse(text.slice(start, end)); } catch {}
        }
      }
    }
    return null;
  };

  const VARIANT_GROUP_FR = [
    [/颜色|色|colou?r/i, 'Couleur'],
    [/尺码|尺寸|size|taille/i, 'Taille'],
    [/长度|length|longueur/i, 'Longueur'],
    [/功率|power|watt|puissance/i, 'Puissance'],
    [/容量|capacity|capacité/i, 'Capacité'],
    [/电压|voltage|tension/i, 'Tension'],
    [/插头|plug|prise/i, 'Prise'],
    [/套餐|package|bundle|pack/i, 'Pack'],
    // Générique en dernier : « Plug Type » doit rester « Prise »
    [/规格|型号|款式|款|model|style|type/i, 'Modèle'],
  ];
  const frGroupName = (name) => {
    const n = String(name || '').trim();
    for (const [re, fr] of VARIANT_GROUP_FR) if (re.test(n)) return fr;
    return n || 'Options';
  };
  const decodeEntities = (s) => String(s || '').replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&amp;/g, '&').replace(/&quot;/g, '"');
  const num = (v) => { const n = parseFloat(typeof v === 'object' && v ? (v.value ?? v.amount ?? v.price) : v); return Number.isFinite(n) && n > 0 ? n : undefined; };

  /**
   * Variantes depuis l'état JSON de la page (fiable même si le DOM est minifié) :
   * - 1688 : skuProps [{prop, value:[{name,imageUrl}]}] + skuInfoMap {"红色>10米": {price, discountPrice, canBookCount}}
   * - AliExpress : productSKUPropertyList [{skuPropertyName, skuPropertyValues:[…]}] + skuPriceList
   * Prix par option = prix minimal des combinaisons qui la contiennent.
   */
  const extractVariantsFromScripts = () => {
    // ── 1688 ──
    const skuProps = extractJsonAfterKey('skuProps');
    if (Array.isArray(skuProps) && skuProps.length) {
      const infoMap = extractJsonAfterKey('skuInfoMap') || {};
      const combos = Object.entries(infoMap).map(([k, v]) => ({
        parts: decodeEntities(k).split('>').map(p => p.trim()),
        price: num(v?.discountPrice) || num(v?.price),
        stock: Number(v?.canBookCount ?? v?.saleCount ?? 0) || 0,
      }));
      const groups = skuProps.map(g => {
        const values = Array.isArray(g?.value) ? g.value : [];
        const variants = values.map((v, idx) => {
          const name = String(v?.name || '').trim();
          if (!name) return null;
          const matching = combos.filter(c => c.parts.includes(name));
          const prices = matching.map(c => c.price).filter(Boolean);
          const stock = matching.reduce((s, c) => s + c.stock, 0);
          const image = v?.imageUrl ? cleanImageUrl(v.imageUrl) : undefined;
          return {
            id: `sku-${idx}`,
            name,
            image,
            price1688: prices.length ? Math.min(...prices) : undefined,
            stock: stock || 1000,
            isDefault: idx === 0,
          };
        }).filter(Boolean);
        return { name: frGroupName(g?.prop || g?.name), sourceName: g?.prop || '', variants };
      }).filter(g => g.variants.length > 0);
      if (groups.some(g => g.variants.length > 1)) return groups;
    }

    // ── AliExpress ──
    const propList = extractJsonAfterKey('productSKUPropertyList') || extractJsonAfterKey('skuPropertyList');
    if (Array.isArray(propList) && propList.length) {
      const priceList = extractJsonAfterKey('skuPriceList') || [];
      const combos = (Array.isArray(priceList) ? priceList : []).map(c => ({
        ids: String(c?.skuPropIds || '').split(',').map(s => s.trim()),
        price: num(c?.skuVal?.skuActivityAmount) || num(c?.skuVal?.skuAmount) || num(c?.skuVal?.actSkuCalPrice) || num(c?.skuVal?.skuCalPrice),
        stock: Number(c?.skuVal?.availQuantity ?? 0) || 0,
      }));
      const groups = propList.map(g => {
        const values = g?.skuPropertyValues || g?.skuPropertyValueList || [];
        const variants = values.map((v, idx) => {
          const name = String(v?.propertyValueDisplayName || v?.propertyValueDefinitionName || v?.propertyValueName || '').trim();
          if (!name) return null;
          const id = String(v?.propertyValueId ?? v?.propertyValueIdLong ?? '');
          const matching = combos.filter(c => id && c.ids.some(x => x.endsWith(`:${id}`) || x === id));
          const prices = matching.map(c => c.price).filter(Boolean);
          const image = v?.skuPropertyImagePath || v?.skuPropertyImageSummPath;
          return {
            id: `sku-${idx}`,
            name,
            image: image ? cleanImageUrl(image) : undefined,
            price1688: prices.length ? Math.min(...prices) : undefined,
            stock: matching.reduce((s, c) => s + c.stock, 0) || 1000,
            isDefault: idx === 0,
          };
        }).filter(Boolean);
        return { name: frGroupName(g?.skuPropertyName), sourceName: g?.skuPropertyName || '', variants };
      }).filter(g => g.variants.length > 0);
      if (groups.some(g => g.variants.length > 1)) return groups;
    }

    // ── Alibaba.com : skuAttrs [{id,name,values:[{id,name,largeImage|image}]}] + skuInfoMap {"aid:vid;aid:vid": {price…}} ──
    const attrs = extractJsonAfterKey('skuAttrs') || extractJsonAfterKey('skuAttributes') || extractJsonAfterKey('skuProperties');
    if (Array.isArray(attrs) && attrs.length) {
      const infoRaw = extractJsonAfterKey('skuInfoMap') || extractJsonAfterKey('skuInfoList') || extractJsonAfterKey('skuList') || {};
      const infoEntries = Array.isArray(infoRaw)
        ? infoRaw.map(s => [String(s?.skuAttr || s?.attrs || s?.skuAttrStr || s?.key || ''), s])
        : Object.entries(infoRaw);
      const priceOf = (s) => num(s?.price?.price) || num(s?.price?.value) || num(s?.price) || num(s?.discountPrice)
        || num(s?.ladderPrices?.[0]?.price) || num(s?.priceFormatted) || num(s?.skuPrice);
      const combos = infoEntries.map(([key, s]) => ({
        ids: decodeEntities(key).split(/[;,]/).map(x => x.trim()).filter(Boolean),
        price: priceOf(s),
        stock: Number(s?.inventory ?? s?.stock ?? s?.availQuantity ?? 0) || 0,
      }));
      const groups = attrs.map(g => {
        const attrId = String(g?.id ?? g?.attrId ?? g?.pid ?? '');
        const values = g?.values || g?.valueList || g?.attrValues || g?.skuAttrValues || [];
        const variants = (Array.isArray(values) ? values : []).map((v, idx) => {
          const name = String(v?.name || v?.valueName || v?.text || v?.value || '').trim();
          if (!name) return null;
          const vid = String(v?.id ?? v?.valueId ?? v?.vid ?? '');
          const matching = combos.filter(c => vid && c.ids.some(x => x === `${attrId}:${vid}` || x.endsWith(`:${vid}`) || x === vid));
          const prices = matching.map(c => c.price).filter(Boolean);
          const image = v?.largeImage || v?.originImage || v?.bigImage || v?.image || v?.imageUrl || v?.skuImage;
          return {
            id: `sku-${idx}`,
            name,
            image: image ? cleanImageUrl(String(image)) : undefined,
            price1688: prices.length ? Math.min(...prices) : undefined,
            stock: matching.reduce((s, c) => s + c.stock, 0) || 1000,
            isDefault: idx === 0,
          };
        }).filter(Boolean);
        return { name: frGroupName(g?.name || g?.attrName || g?.propName), sourceName: g?.name || '', variants };
      }).filter(g => g.variants.length > 0);
      if (groups.some(g => g.variants.length > 1)) return groups;
    }
    return [];
  };

  /** Fusion : la structure JSON prime ; le DOM complète les images manquantes. */
  const mergeVariantGroups = (fromScripts, fromDom) => {
    if (!fromScripts.length) return fromDom;
    const domImages = new Map();
    (fromDom || []).forEach(g => (g.variants || []).forEach(v => { if (v.image) domImages.set(v.name, v.image); }));
    return fromScripts.map(g => ({
      name: g.name,
      variants: g.variants.map(v => ({ ...v, image: v.image || domImages.get(v.name) })),
    }));
  };

  /** Trouver un objet ressemblant à un produit dans un arbre JSON */
  const findProductLikeObject = (root, depth = 5, seen = new WeakSet()) => {
    if (!root || depth < 0) return null;
    if (seen.has(root)) return null;
    if (Array.isArray(root)) {
      for (const item of root) {
        const r = findProductLikeObject(item, depth - 1, seen);
        if (r) return r;
      }
      return null;
    }
    if (typeof root === 'object') {
      seen.add(root);
      const hasTitle = root.title || root.subject || root.productTitle || root.name;
      const hasPrice = root.price !== undefined || root.priceInfo || root.salePrice || root.amount || root.priceRange || root.minPrice || root.maxPrice;
      const hasImages = root.images || root.image || root.imgList || root.gallery || root.picList || root.imageList || root.imageUrls;
      if (hasTitle && hasPrice && hasImages) return root;
      for (const v of Object.values(root)) {
        const r = findProductLikeObject(v, depth - 1, seen);
        if (r) return r;
      }
    }
    return null;
  };

  /** Tenter de récupérer l'état produit depuis les variables globales/inline scripts */
  const getPageProductState = () => {
    const names = ['window.__INITIAL_STATE__', 'window.__APP_INITIAL_STATE__', 'window._DATA', 'window.__GLOBAL_DATA__', 'window.__DATA__', 'window.runParams', 'window.__INITIAL_STATE'];
    for (const name of names) {
      const extracted = extractScriptObject(name);
      if (extracted) {
        const found = findProductLikeObject(extracted);
        if (found) return found;
      }
    }
    return null;
  };

  /** Extraction simple et générique depuis un objet produit d'état */
  const parsePageProductState = (state) => {
    const out = { name: '', price1688: 0, priceUSD: 0, gallery: [], descriptionImages: [], videos: [], variantGroups: [], specifications: {}, shopName: '', weightKg: 0, lengthCm: 0, widthCm: 0, heightCm: 0 };
    if (!state) return out;

    out.name = state.title || state.subject || state.productTitle || state.name || '';

    const price = state.price || state.salePrice || state.amount || state.priceRange || state.minPrice || state.priceInfo;
    if (typeof price === 'number') out.price1688 = price;
    else if (price && typeof price === 'object') {
      if (typeof price.amount === 'number') out.price1688 = price.amount;
      else if (typeof price.price === 'number') out.price1688 = price.price;
      else if (typeof price.minPrice === 'number') out.price1688 = price.minPrice;
      else if (typeof price.value === 'number') out.price1688 = price.value;
    }

    const images = state.images || state.image || state.imgList || state.gallery || state.picList || state.imageList || state.imageUrls;
    if (images) {
      const arr = Array.isArray(images) ? images : [images];
      out.gallery = arr
        .map((img) => {
          if (typeof img === 'string') return img;
          return img?.url || img?.src || img?.imageUrl || img?.original || img?.big || img?.full || '';
        })
        .filter(Boolean)
        .map(cleanImageUrl)
        .filter((u) => !isNoiseImage(u));
    }

    const descImages = state.descriptionImages || state.descriptionImageList || state.detailImages || state.descImages;
    if (descImages) {
      const arr = Array.isArray(descImages) ? descImages : [descImages];
      out.descriptionImages = arr
        .map((img) => (typeof img === 'string' ? img : img?.url || img?.src || img?.imageUrl || ''))
        .filter(Boolean)
        .map(cleanImageUrl)
        .filter((u) => !isNoiseImage(u));
    }

    const videos = state.videos || state.videoList || state.videoUrl;
    if (videos) {
      const arr = Array.isArray(videos) ? videos : [videos];
      out.videos = arr
        .map((v) => (typeof v === 'string' ? v : v?.url || v?.videoUrl || v?.src || ''))
        .filter((u) => typeof u === 'string' && u.startsWith('http'));
    }

    const props = state.props || state.properties || state.attributes || state.specifications || state.productProps || state.skuProps;
    if (props && typeof props === 'object') {
      if (Array.isArray(props)) {
        props.forEach((p) => {
          if (p && p.name && p.value) out.specifications[p.name] = p.value;
        });
      } else {
        Object.assign(out.specifications, props);
      }
    }

    out.shopName = state.shopName || state.supplierName || state.supplier?.name || state.seller?.name || state.shopInfo?.name || state.storeName || '';

    // Poids/dimensions depuis specs
    if (state.weight) out.weightKg = state.weight;
    if (state.width) out.widthCm = state.width;
    if (state.height) out.heightCm = state.height;
    if (state.length) out.lengthCm = state.length;

    return out;
  };

  // ==========================================
  // CLASSIFICATION CATEGORIE IT VISION
  // ==========================================

  const CATEGORY_RULES = [
    { name: 'Sécurité', keywords: ['camera','caméra','surveillance','cctv','dvr','nvr','ip camera','poe','alarme','intrusion','détecteur','detecteur','capteur','mouvement','présence','serrure','lock','empreinte','fingerprint','badge','portier','interphone','vidéo','video'] },
    { name: 'Informatique & Bureautique', keywords: ['ordinateur','laptop','pc','clavier','souris','écran','ecran','cable','câble','switch','routeur','router','hub','usb','hdmi','réseau','reseau','network','bureautique','imprimante','scanner','disque dur','ssd','ram','mémoire','webcam','microphone'] },
    { name: 'Domotique & Smart Home', keywords: ['domotique','smart home','maison connectée','sonoff','tuya','zigbee','wifi switch','capteur','sensor','thermostat','interrupteur connecté','prise connectée','smart plug','automation'] },
    { name: 'Électronique grand public', keywords: ['smartphone','téléphone','telephone','earphone','écouteur','headphone','casque','chargeur','power bank','batterie','bluetooth','speaker','enceinte','tv box','android box','drone','montre connectée','smartwatch','tablette'] },
    { name: 'Mobilier & Installation', keywords: ['rack','baie','armoire','server cabinet','coffret','bureau','chaise','table','mobilier','meuble','établi','poste de travail'] },
    { name: 'Packs & Cadeaux', keywords: ['pack','lot','coffret','cadeau','gift','box','ensemble','kit'] }
  ];

  const classifyCategory = (name, description, specs) => {
    const text = `${name || ''} ${description || ''} ${Object.entries(specs || {}).map(([k, v]) => `${k} ${v}`).join(' ')}`.toLowerCase();
    let best = null, bestScore = 0;
    for (const cat of CATEGORY_RULES) {
      let score = 0;
      for (const kw of cat.keywords) {
        if (text.includes(kw.toLowerCase())) score += 1;
      }
      if (score > bestScore) {
        bestScore = score;
        best = cat.name;
      }
    }
    return bestScore >= 2 ? best : 'Catalogue import Chine';
  };

  // ==========================================
  // EXTRACTEUR 1688 (v2)
  // ==========================================

  const scrape1688 = async () => {
    console.log('[IT Vision] Extraction 1688 v2...');

    const bodyText = (document.body?.innerText || '').slice(0, 5000);
    if (
      /login\.1688\.com|member\/signin|_____tmd_____/.test(window.location.href) ||
      /(member\s*signin|请登录|登录|账户登录|taobao\s*login)/i.test(bodyText)
    ) {
      throw new Error('1688 nécessite une session connectée. Connectez-vous sur 1688, rechargez la page produit puis relancez l’extraction.');
    }
    
    const data = {
      platform: '1688',
      url: window.location.href.split('?')[0],
      timestamp: new Date().toISOString(),
      gallery: [],
      descriptionImages: [],
      videos: [],
      variantGroups: [],
      features: [],
      specifications: {}
    };

    // Données structurées depuis les scripts inline (fallback fiable si le DOM est React/minifié)
    const pageState = parsePageProductState(getPageProductState());

    try {
      await wait(2000);

      // Scroll profond (1688 charge description et images en lazy-load très loin)
      await deepScroll(8000, 400, 300);

      // Cliquer sur onglets "详情" (détails) / "商品描述" pour charger la description
      try {
        document.querySelectorAll('[role="tab"], [class*="tab" i] li, [class*="Tab" i] a, [class*="tab-item" i], [class*="detail" i] [class*="tab" i]').forEach(tab => {
          const t = (tab.textContent || '').trim();
          if (t.includes('详情') || t.includes('描述') || t.includes('详细') || t.includes('detail')) {
            tab.click();
            console.log('[IT Vision] Onglet 1688 cliqué:', t);
          }
        });
        await wait(2000);
        // Re-scroll après clic onglet
        await deepScroll(6000, 500, 200);
      } catch (e) { console.warn('[IT Vision] Onglets 1688:', e); }
    } catch (e) { console.warn('[IT Vision] Scroll 1688:', e); }

    // ── TITRE ──
    try {
      data.name = trySelectors([
        '.offer-title', '.detail-title', 'h1[data-spm="title"]',
        'h1.title', '.title-text', '.mod-detail-title h1',
        '[class*="offerTitle"]', '[class*="DetailTitle"]',
        '[class*="title-text" i]', '[class*="offer-title" i]', 'h1'
      ]) || document.title.replace(/[-|].*$/, '').trim() || 'Produit 1688';
    } catch { data.name = document.title.replace(/[-|].*$/, '').trim() || 'Produit 1688'; }

    // ── PRIX + PALIERS ──
    try {
      const priceEl = document.querySelector(
        '.price-now .price-num, .price .price-num, .offer-price, ' +
        '[class*="price"] [class*="num"], [class*="Price"] [class*="Num"], ' +
        '.mod-detail-price .price, [data-price]'
      );
      const priceMatch = priceEl?.textContent?.match(/(\d+(?:\.\d+)?)/);
      data.price1688 = priceMatch ? parseFloat(priceMatch[1]) : null;
      // Repli : état JSON de la page, puis premier « ¥ 12.5 » de la zone prix
      if (!(data.price1688 > 0) && pageState.price1688 > 0) data.price1688 = pageState.price1688;
      if (!(data.price1688 > 0)) {
        const area = document.querySelector('[class*="price" i]')?.textContent || '';
        const ym = area.match(/[¥￥]\s*(\d+(?:\.\d+)?)/);
        if (ym) data.price1688 = parseFloat(ym[1]);
      }

      const priceTiers = [];
      document.querySelectorAll(
        '[class*="price"] tr, [class*="Price"] tr, .price-range-item, .batch-price-item, ' +
        '[class*="batchPrice" i] [class*="item" i], [class*="step-price" i] [class*="item" i]'
      ).forEach(row => {
        const texts = row.textContent || '';
        const qtyMatch = texts.match(/(\d+)\s*[-~≥>=]\s*(\d+)?/);
        const prMatch = texts.match(/[¥￥]?\s*(\d+(?:\.\d+)?)/);
        if (qtyMatch && prMatch) {
          priceTiers.push({
            minQty: parseInt(qtyMatch[1]),
            maxQty: qtyMatch[2] ? parseInt(qtyMatch[2]) : undefined,
            price: parseFloat(prMatch[1])
          });
        }
      });
      if (priceTiers.length > 0) data.priceTiers = priceTiers;

      // Prix promo si visible
      const promoPriceEl = document.querySelector('[class*="promotion" i] [class*="price" i], [class*="sale" i] [class*="price" i]');
      if (promoPriceEl) {
        const pm = promoPriceEl.textContent?.match(/(\d+(?:\.\d+)?)/);
        if (pm) data.promoPrice1688 = parseFloat(pm[1]);
      }
    } catch (e) { console.warn('[IT Vision] Prix 1688:', e); }

    // ── IMAGES — classées par catégorie ──
    const imageCategories = { main: [], gallery: [], variant: [], description: [], packaging: [] };
    try {
      // Images galerie principale — sélecteurs larges pour couvrir 1688 classique + React
      const gallerySelectors = [
        '.detail-gallery img', '.offer-img img', '.main-image img',
        '[class*="gallery" i] img', '[class*="slider" i] img',
        '[class*="image-view" i] img', '[class*="thumb" i] img',
        '[class*="detail-image" i] img', '[class*="mainImg" i] img',
        // 1688 React / moderne
        '[class*="image--item" i] img', '[class*="ImageView" i] img',
        '[class*="carousel" i] img', '[class*="swiper" i] img',
        'picture img', '[class*="pic" i][class*="wrap" i] img',
        '[class*="sku" i] img', '[data-role="img"] img',
        // Fallback large : toute image sur CDN alicdn dans la zone produit
        '[class*="detail" i] img', '[class*="offer" i] img'
      ];
      for (const sel of gallerySelectors) {
        document.querySelectorAll(sel).forEach(img => {
          if (isNoiseImageElement(img)) return;
          const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-original') || '';
          if (!src || isNoiseImage(src)) return;
          if (!is1688ProductImage(src)) return;
          const clean = cleanImageUrl(src);
          if (clean && !imageCategories.gallery.includes(clean)) imageCategories.gallery.push(clean);
        });
      }

      // Recherche élargie : toutes les images CDN 1688 dans le body
      if (imageCategories.gallery.length < 3) {
        console.log('[IT Vision] 1688 recherche élargie images...');
        document.querySelectorAll('img').forEach(img => {
          if (isNoiseImageElement(img)) return;
          const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-original') || '';
          if (!src || isNoiseImage(src) || !is1688ProductImage(src)) return;
          const clean = cleanImageUrl(src);
          if (clean && !imageCategories.gallery.includes(clean)) imageCategories.gallery.push(clean);
        });
      }

      // og:image fallback
      if (imageCategories.gallery.length === 0) {
        const ogImg = document.querySelector('meta[property="og:image"]')?.getAttribute('content');
        if (ogImg) imageCategories.gallery.push(cleanImageUrl(ogImg));
      }

      // Première image = main
      if (imageCategories.gallery.length > 0) {
        imageCategories.main = [imageCategories.gallery[0]];
      }

      // Images de description (dans la section détails en bas de page)
      const descContainers = document.querySelectorAll(
        '.detail-desc, [class*="offerDesc" i], [class*="offer-desc" i], [class*="detail-desc" i], ' +
        '#desc-lazyload-container, [class*="descV8" i], [id*="desc" i], ' +
        '[class*="description" i] img, [class*="tab-content" i]'
      );
      descContainers.forEach(container => {
        container.querySelectorAll('img').forEach(img => {
          const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-original') || '';
          if (!src || isNoiseImage(src)) return;
          const w = img.naturalWidth || parseInt(img.getAttribute('width') || '0');
          const h = img.naturalHeight || parseInt(img.getAttribute('height') || '0');
          if (w > 0 && w < 100) return; // trop petit
          if (h > 0 && h < 100) return;
          const clean = cleanImageUrl(src);
          if (clean && !imageCategories.description.includes(clean) && !imageCategories.gallery.includes(clean)) {
            imageCategories.description.push(clean);
          }
        });
      });

      // Packaging detection: images contenant "packaging", "包装", "box"
      const allDescImgs = [...imageCategories.description];
      imageCategories.description = allDescImgs.filter(url => {
        const lower = url.toLowerCase();
        if (/packag|包装|box|carton|emball/i.test(lower)) {
          imageCategories.packaging.push(url);
          return false;
        }
        return true;
      });

      data.gallery = deduplicateImages(imageCategories.gallery).length > 0
        ? deduplicateImages(imageCategories.gallery).slice(0, 20)
        : pageState.gallery.slice(0, 20);
      data.descriptionImages = deduplicateImages(imageCategories.description).slice(0, 30);
      if (data.descriptionImages.length === 0 && pageState.descriptionImages.length) {
        data.descriptionImages = deduplicateImages(pageState.descriptionImages).slice(0, 30);
      }
      data.image = data.gallery[0] || imageCategories.main[0];
      data.imageCategories = {
        main: imageCategories.main.slice(0, 1),
        gallery: data.gallery,
        variant: [],
        description: data.descriptionImages,
        packaging: deduplicateImages(imageCategories.packaging).slice(0, 5)
      };
      console.log('[IT Vision] 1688 Images:', data.gallery.length, 'galerie,', data.descriptionImages.length, 'description');
    } catch (e) { data.gallery = []; console.warn('[IT Vision] Images 1688:', e); }

    // ── VIDÉOS ──
    try {
      data.videos = extractVideos(document);
      console.log('[IT Vision] 1688 Vidéos:', data.videos.length);
    } catch { data.videos = []; }

    // ── VARIANTES ──
    try {
      data.variantGroups = [];
      const processedGroups = new Set();

      document.querySelectorAll('[class*="sku" i], [class*="Sku" i], [class*="prop" i], [class*="variant" i]').forEach(container => {
        const labelEl = container.querySelector('[class*="title" i], [class*="label" i], [class*="name" i], dt, h4, h5, strong');
        let groupName = labelEl?.textContent?.trim()?.replace(/[:\s：]+$/, '')?.trim() || '';
        groupName = groupName.replace(/\s*[:\s：].*$/, '').trim();
        if (!groupName || groupName.length > 40 || groupName.length < 1 || processedGroups.has(groupName)) return;

        // Normaliser nom de groupe
        const gl = groupName.toLowerCase();
        if (gl.includes('颜色') || gl.includes('色')) groupName = 'Couleur';
        else if (gl.includes('尺') || gl.includes('码') || gl.includes('规格')) groupName = 'Taille';
        else if (gl.includes('款') || gl.includes('型号')) groupName = 'Modèle';

        const variants = [];
        container.querySelectorAll('li, [class*="item" i], [class*="option" i], [class*="prop-value" i]').forEach((item, idx) => {
          const text = item.textContent?.trim();
          if (!text || text.length > 80 || text.length < 1 || text === groupName) return;
          if (item === labelEl || item.contains(labelEl)) return;

          const img = item.querySelector('img');
          let imgUrl = img?.getAttribute('src') || img?.getAttribute('data-src') || undefined;
          if (imgUrl) {
            imgUrl = cleanImageUrl(imgUrl);
            // Ajouter aux images de variante
            if (imgUrl && !imageCategories.variant.includes(imgUrl)) imageCategories.variant.push(imgUrl);
          }

          const priceMatch = text.match(/[¥￥]\s*(\d+(?:\.\d+)?)/);
          const variantPrice = priceMatch ? parseFloat(priceMatch[1]) : undefined;
          const cleanName = text.replace(/[¥￥]\s*\d+(?:\.\d+)?/, '').trim() || text;

          if (!variants.find(v => v.name === cleanName)) {
            variants.push({
              id: `sku-${idx}`,
              name: cleanName,
              image: imgUrl || undefined,
              price1688: variantPrice || data.price1688,
              stock: 1000,
              isDefault: idx === 0
            });
          }
        });

        if (variants.length > 1) {
          processedGroups.add(groupName);
          data.variantGroups.push({ name: groupName, variants });
          console.log('[IT Vision] 1688 Variante:', groupName, '→', variants.length, 'options');
        }
      });

      // Fallback items plats
      if (data.variantGroups.length === 0) {
        const variants = [];
        document.querySelectorAll('.sku-item, .offer-sku, .prop-item').forEach((item, idx) => {
          const name = item.textContent?.trim();
          const img = item.querySelector('img');
          let imgUrl = img?.getAttribute('src') || img?.getAttribute('data-src') || undefined;
          if (imgUrl) imgUrl = cleanImageUrl(imgUrl);
          if (name && name.length > 0 && name.length < 80 && !variants.find(v => v.name === name)) {
            variants.push({ id: `sku-${idx}`, name, image: imgUrl, price1688: data.price1688, stock: 1000, isDefault: idx === 0 });
          }
        });
        if (variants.length > 1) data.variantGroups.push({ name: 'Modèle', variants });
      }

      // Source fiable : l'état JSON de la page (prix, stock et image par déclinaison)
      const scriptGroups = extractVariantsFromScripts();
      if (scriptGroups.length) {
        data.variantGroups = mergeVariantGroups(scriptGroups, data.variantGroups);
        data.variantGroups.forEach(g => g.variants.forEach(v => {
          if (v.image && !imageCategories.variant.includes(v.image)) imageCategories.variant.push(v.image);
        }));
        console.log('[IT Vision] 1688 Variantes (JSON):', data.variantGroups.map(g => `${g.name}(${g.variants.length})`).join(', '));
      }

      // Mettre à jour les images de variante
      if (data.imageCategories) {
        data.imageCategories.variant = deduplicateImages(imageCategories.variant).slice(0, 40);
      }
    } catch (e) { console.warn('[IT Vision] Variantes 1688:', e); }

    // ── MOQ ──
    try {
      const moqEl = document.querySelector('.moq-info, [class*="moq"], .min-order, [class*="MinOrder"], [class*="minOrder"]');
      if (moqEl) {
        const moqMatch = moqEl.textContent.match(/(\d+)\s*(?:件|个|pcs|pi[eè]ces?|unit)/i);
        data.moq = moqMatch ? parseInt(moqMatch[1]) : null;
      }
      if (!data.moq) {
        const bodyText = document.body.innerText.slice(0, 5000);
        const moqFallback = bodyText.match(/(?:起订|最少|minimum)[^\d]*(\d+)/i);
        if (moqFallback) data.moq = parseInt(moqFallback[1]);
      }
    } catch (e) { console.warn('[IT Vision] MOQ 1688:', e); }

    // ── SPÉCIFICATIONS ──
    const specs = {};
    try {
      document.querySelectorAll(
        '.offer-attr-row, .parameter-row, [class*="attr"] tr, [class*="Attr"] tr, ' +
        '[class*="param"] tr, [class*="detail-attr" i] li, [class*="attribute" i] li'
      ).forEach(row => {
        const cells = row.querySelectorAll('td, .attr-name, .attr-value, th, span');
        if (cells.length >= 2) {
          const key = cells[0].textContent?.trim();
          const value = cells[1].textContent?.trim();
          if (key && value && key.length < 50 && value.length < 200) specs[key] = value;
        }
      });
      data.specifications = specs;
    } catch (e) { data.specifications = {}; }

    // Fallback specs depuis l'état JS de la page
    if (Object.keys(data.specifications || {}).length === 0 && Object.keys(pageState.specifications || {}).length > 0) {
      data.specifications = pageState.specifications;
    }

    // ── POIDS / DIMENSIONS ──
    let weightKg = 0, lengthCm = 0, widthCm = 0, heightCm = 0;
    try {
      for (const [key, value] of Object.entries(specs)) {
        const k = key.toLowerCase();
        if (k.includes('重量') || k.includes('weight') || k.includes('净重') || k.includes('毛重')) {
          const wm = String(value).match(/(\d+(?:\.\d+)?)\s*(?:kg|千克)/i);
          if (wm) weightKg = parseFloat(wm[1]);
          if (!wm) {
            const wg = String(value).match(/(\d+(?:\.\d+)?)\s*(?:g|克)/i);
            if (wg) weightKg = parseFloat(wg[1]) / 1000;
          }
        }
        if (k.includes('尺寸') || k.includes('dimension') || k.includes('size') || k.includes('规格') || k.includes('大小')) {
          const dims = String(value).match(/(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)/i);
          if (dims) {
            lengthCm = parseFloat(dims[1]);
            widthCm = parseFloat(dims[2]);
            heightCm = parseFloat(dims[3]);
            // Si les valeurs sont en mm (< 1), convertir
            if (lengthCm > 0 && lengthCm < 1) { lengthCm *= 10; widthCm *= 10; heightCm *= 10; }
          }
        }
      }
    } catch (e) { console.warn('[IT Vision] Poids/dim 1688:', e); }

    // ── DESCRIPTION STRUCTURÉE (NOUVEAU) ──
    let presentationText = '';
    try {
      // Extraire le texte de la section description
      const descContainers = document.querySelectorAll(
        '.detail-desc, [class*="offerDesc" i], [class*="offer-desc" i], ' +
        '#desc-lazyload-container, [class*="descV8" i], [id*="desc" i]'
      );
      for (const container of descContainers) {
        const text = cleanTextFromElement(container);
        if (text.length > presentationText.length) presentationText = text;
      }

      // Nettoyer le texte brut chinois : supprimer les lignes inutiles
      if (presentationText) {
        presentationText = presentationText
          .split('\n')
          .map(l => l.trim())
          .filter(l => {
            if (l.length < 3) return false;
            // Supprimer lignes "en savoir plus", pubs, liens
            if (/^(查看|了解|点击|联系|more|click|contact)/i.test(l)) return false;
            if (/^\d+$/.test(l)) return false;
            return true;
          })
          .join('\n')
          .replace(/\n{3,}/g, '\n\n')
          .slice(0, 5000);
      }
    } catch (e) { console.warn('[IT Vision] Description 1688:', e); }

    // Construire la description structurée
    data.description = buildStructuredDescription({
      title: data.name,
      specs,
      presentationText
    });

    // Fallback poids/dimensions depuis l'état JS de la page
    if (!weightKg && pageState.weightKg) weightKg = pageState.weightKg;
    if (!lengthCm && pageState.lengthCm) lengthCm = pageState.lengthCm;
    if (!widthCm && pageState.widthCm) widthCm = pageState.widthCm;
    if (!heightCm && pageState.heightCm) heightCm = pageState.heightCm;
    if (pageState.shopName && !data.supplier) data.supplier = { name: pageState.shopName };

    // ── IMAGES : classement final (données JSON de la page + DOM) ──
    try { finalizeImages(data); } catch (e) { console.warn('[IT Vision] Classement images 1688:', e); }

    // ── VALEURS PAR DÉFAUT ──
    try {
      data.category = classifyCategory(data.name, data.description, data.specifications) || 'Catalogue import Chine';
      data.tagline = 'Import 1688';
      data.availabilityNote = 'Import 1688 - vérifier poids/dimensions';
      data.currency = 'FCFA';
      data.price1688Currency = 'CNY';
      data.exchangeRate = 100;
      if (typeof weightKg !== 'undefined' && weightKg > 0) data.weightKg = weightKg;
      if (typeof lengthCm !== 'undefined' && lengthCm > 0) data.lengthCm = lengthCm;
      if (typeof widthCm !== 'undefined' && widthCm > 0) data.widthCm = widthCm;
      if (typeof heightCm !== 'undefined' && heightCm > 0) data.heightCm = heightCm;
      data.features = [
        data.moq && `MOQ: ${data.moq} unités`,
        data.priceTiers?.length && `${data.priceTiers.length} paliers de prix`,
        Object.keys(data.specifications || {}).length > 0 && `${Object.keys(data.specifications).length} spécifications`,
        data.videos?.length > 0 && `${data.videos.length} vidéo(s)`,
        data.gallery?.length > 0 && `${data.gallery.length} images galerie`,
        data.descriptionImages?.length > 0 && `${data.descriptionImages.length} images description`,
        data.weightKg && `Poids: ${data.weightKg} kg`
      ].filter(Boolean);
    } catch (e) { console.warn('[IT Vision] Défaut 1688:', e); }

    if (!data.name) data.name = document.title.replace(/[-|].*$/, '').trim() || 'Produit 1688';
    if (!data.image && data.gallery?.length) data.image = data.gallery[0];

    console.log('[IT Vision] 1688 extrait:', {
      name: data.name,
      price: data.price1688,
      gallery: data.gallery?.length,
      descImages: data.descriptionImages?.length,
      videos: data.videos?.length,
      variants: data.variantGroups?.length
    });
    return data;
  };

  // ==========================================
  // EXTRACTEUR ALIEXPRESS
  // ==========================================
  
  const scrapeAliExpress = async () => {
    console.log('[IT Vision] Extraction AliExpress v2...');

    await wait(3000);
    // Scroll profond pour déclencher lazy load (description est en bas)
    const docHeight = Math.max(document.body.scrollHeight, 6000);
    await deepScroll(docHeight, 400, 200);
    await wait(1000);

    // Cliquer sur les onglets Description / Détails / Spécifications
    try {
      const tabSelectors = [
        '[data-pl="product-description"]',
        '[class*="tab" i][class*="item" i]',
        '[role="tab"]',
        'div[class*="Tab"] span',
        'button[class*="tab" i]',
        '.detail-tab-item', '.product-tab'
      ];
      for (const sel of tabSelectors) {
        document.querySelectorAll(sel).forEach(tab => {
          const text = (tab.textContent || '').toLowerCase();
          if (text.includes('description') || text.includes('detail') || text.includes('détail')
              || text.includes('specification') || text.includes('spécification')
              || text.includes('overview') || text.includes('présentation')) {
            tab.click();
            console.log('[IT Vision] Onglet cliqué:', text.trim());
          }
        });
      }
      await wait(2000);
      // Re-scroll pour charger le contenu lazy des onglets
      window.scrollTo(0, document.body.scrollHeight / 2);
      await wait(1000);
    } catch (e) {
      console.warn('[IT Vision] Erreur clic onglets:', e);
    }

    window.scrollTo(0, 0);
    await wait(300);

    const data = {
      platform: 'aliexpress',
      url: window.location.href,
      timestamp: new Date().toISOString()
    };

    // ===== SOURCE 1: JSON-LD (le plus fiable) =====
    let jsonLdProduct = null;
    try {
      document.querySelectorAll('script[type="application/ld+json"]').forEach(script => {
        try {
          const parsed = JSON.parse(script.textContent || '');
          const items = Array.isArray(parsed) ? parsed : [parsed];
          for (const item of items) {
            if (item['@type'] === 'Product' && item.name) {
              jsonLdProduct = item;
            }
          }
        } catch {}
      });
    } catch {}

    // ===== SOURCE 2: données structurées depuis scripts inline =====
    const pageState = parsePageProductState(getPageProductState());

    // ===== TITRE =====
    if (jsonLdProduct?.name) {
      data.name = jsonLdProduct.name.trim();
    }
    if (!data.name) {
      // Meta tags
      data.name = document.querySelector('meta[property="og:title"]')?.getAttribute('content')?.trim()
        || document.querySelector('meta[name="title"]')?.getAttribute('content')?.trim();
    }
    if (!data.name) {
      // DOM: chercher h1 ou data-pl
      data.name = trySelectors([
        '[data-pl="product-title"]', 'h1[data-pl="product-title"]',
        'h1', '.product-title'
      ]);
    }
    if (!data.name && pageState.name) data.name = pageState.name;
    if (!data.name) data.name = document.title.replace(/-.*AliExpress.*$/i, '').trim() || 'Produit AliExpress';

    // ===== PRIX =====
    // Convertit un prix brut en FCFA selon la devise détectée
    const convertToFcfa = (rawPrice, currency, textSource = '') => {
      const val = Number(rawPrice);
      if (!Number.isFinite(val) || val <= 0) return null;
      const curr = String(currency || '').toUpperCase();
      const sourceText = String(textSource).toUpperCase();
      const isDh = /\bDH\b|DIRHAM|MAD|د\.م|درهم/.test(sourceText) || sourceText.includes('DH');
      if (curr === 'EUR') return Math.round(val * 656);
      if (curr === 'XOF' || curr === 'FCFA') return Math.round(val);
      if (curr === 'MAD' || isDh) return Math.round(val * 61);
      // USD / GBP / autres -> on considère USD par défaut
      return Math.round(val * 620);
    };

    // JSON-LD price
    // Devise affichée : €, $, FCFA, DH, ¥… → code ISO transmis au serveur (conversion ¥ + transport)
    const detectCurrency = (currency, textSource = '') => {
      const curr = String(currency || '').toUpperCase();
      if (curr) return curr === 'FCFA' || curr === 'CFA' ? 'XOF' : curr;
      const t = String(textSource).toUpperCase();
      if (/F\s?CFA|\bCFA\b|\bXOF\b/.test(t)) return 'XOF';
      if (/€|\bEUR\b/.test(t)) return 'EUR';
      if (/\bDH\b|DIRHAM|\bMAD\b|د\.م|درهم/.test(t)) return 'MAD';
      if (/\bAED\b/.test(t)) return 'AED';
      if (/\bSAR\b/.test(t)) return 'SAR';
      if (/£|\bGBP\b/.test(t)) return 'GBP';
      if (/[¥￥]|\bCNY\b|\bRMB\b/.test(t) && !/US\s?\$|\$/.test(t)) return 'CNY';
      return 'USD';
    };
    const setSalePrice = (val, currency) => {
      data.price1688 = Math.round(val * 100) / 100;
      data.price1688Currency = currency;
    };
    if (jsonLdProduct?.offers) {
      const offers = Array.isArray(jsonLdProduct.offers) ? jsonLdProduct.offers[0] : jsonLdProduct.offers;
      const offerPrice = offers?.price || offers?.lowPrice;
      if (offerPrice) {
        data.priceUSD = parseFloat(offerPrice);
        const converted = convertToFcfa(offerPrice, offers?.priceCurrency, jsonLdProduct.name);
        if (converted) {
          data.price = converted;
          setSalePrice(parseFloat(offerPrice), detectCurrency(offers?.priceCurrency, jsonLdProduct.name));
        }
      }
    }
    if (!data.price) {
      // DOM : prix courant (prix de vente) avant le prix barré
      const allEls = document.querySelectorAll(
        '[class*="price--current" i], [class*="price-default--current" i], [class*="currentPrice" i], ' +
        '[data-pl="product-price"], [class*="Price"], [class*="price"]'
      );
      for (const el of allEls) {
        if (/original|--del\b|strike/i.test(String(el.className || ''))) continue;
        const text = el.textContent || '';
        // Chercher un pattern prix: €12.34, $12.34, 12,34€, DH 12.34, 12.34 MAD, 1 234 FCFA...
        const m = text.match(/(?:[\$€£]|US\$|EUR|MAD|AED|SAR|DH)\s*(\d+[.,]\d+)|(\d+[.,]\d+)\s*(?:[\$€£]|US\$|EUR|MAD|AED|SAR|DH)/i)
          || text.match(/(\d{1,3}(?:[\s\u00a0\u202f.]\d{3})+|\d+)\s*(?:F\s?CFA|CFA|XOF)/i);
        if (m) {
          const isCfa = /CFA|XOF/i.test(m[0]);
          const val = isCfa
            ? parseFloat(String(m[1]).replace(/[\s\u00a0\u202f.]/g, ''))
            : parseFloat((m[1] || m[2]).replace(',', '.'));
          if (val > 0 && val < (isCfa ? 100000000 : 100000)) {
            const converted = isCfa ? Math.round(val) : convertToFcfa(val, '', text);
            if (converted) {
              data.priceUSD = isCfa ? undefined : val;
              data.price = converted;
              setSalePrice(val, isCfa ? 'XOF' : detectCurrency('', m[0] + ' ' + text));
              break;
            }
          }
        }
      }
    }

    // ===== IMAGES (approche ciblée — uniquement galerie produit) =====
    const imageSet = new Set();

    // Utilise les fonctions globales isNoiseImage, isNoiseImageElement, cleanImageUrl, isAliProductImage
    // Source 1: JSON-LD images (le plus fiable)
    if (jsonLdProduct?.image) {
      const imgs = Array.isArray(jsonLdProduct.image) ? jsonLdProduct.image : [jsonLdProduct.image];
      imgs.forEach(img => {
        const url = typeof img === 'string' ? img : img?.url || img?.contentUrl || '';
        if (url && url.startsWith('http') && !isNoiseImage(url)) imageSet.add(cleanImageUrl(url));
      });
    }

    // Source 2: og:image
    const ogImg = document.querySelector('meta[property="og:image"]')?.getAttribute('content');
    if (ogImg && ogImg.startsWith('http') && !isNoiseImage(ogImg)) imageSet.add(ogImg);

    // Source 3: Images de la GALERIE PRODUIT (sélecteurs précis + larges)
    const gallerySelectors = [
      // Sélecteurs très spécifiques AliExpress
      '[class*="slider--img"] img', '[class*="Slider--img"] img',
      '[class*="image-view" i] img', '[class*="ImageView" i] img',
      '[class*="product-image" i] img', '[class*="ProductImage" i] img',
      '[data-pl="product-image"] img', '[class*="magnifier" i] img',
      // Galerie/carousel
      '[class*="gallery" i] img', '[class*="Gallery" i] img',
      '[class*="slider" i] img', '[class*="Slider" i] img',
      // Thumbnails produit (pas review/payment)
      '[class*="thumb" i]:not([class*="review" i]):not([class*="payment" i]) img',
      // AliExpress moderne: les images dans la section principale produit
      '[class*="pdp-info" i] img', '[class*="product-main" i] img',
      '[class*="detail-gallery" i] img', '[class*="DetailGallery" i] img',
      // Sélecteurs supplémentaires AliExpress 2024-2026
      '[class*="image--item"] img', '[class*="Image--item"] img',
      'picture img', '[class*="pic" i][class*="wrap" i] img',
      '[class*="main-image" i] img', '[class*="MainImage" i] img',
      '[class*="image--container"] img', '[class*="Image--container"] img',
      '[class*="carousel" i] img', '[class*="swiper" i] img'
    ];
    for (const sel of gallerySelectors) {
      document.querySelectorAll(sel).forEach(img => {
        const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || '';
        if (!src || isNoiseImage(src)) return;
        if (isAliProductImage(src)) {
          imageSet.add(cleanImageUrl(src));
        }
      });
    }

    // Source 4: background-image dans les div de gallery
    document.querySelectorAll('[class*="gallery" i] [style*="background-image"], [class*="slider" i] [style*="background-image"], [class*="image-view" i] [style*="background-image"]').forEach(el => {
      const bg = el.style.backgroundImage;
      const m = bg.match(/url\(["']?([^"')]+)/);
      if (m && !isNoiseImage(m[1]) && isAliProductImage(m[1])) {
        imageSet.add(cleanImageUrl(m[1]));
      }
    });

    // Source 5: Chercher TOUTES les images produit dans le haut de page
    // Toujours exécuté (pas seulement si <= 2) car les sélecteurs spécifiques peuvent rater des images
    console.log('[IT Vision] Recherche élargie d\'images produit...');
    const aliMainZones = [
      '[class*="gallery" i]',
      '[class*="image-view" i]',
      '[class*="main-image" i]',
      '[class*="pdp-main" i]',
      '[class*="product-main" i]',
      '[class*="detail-gallery" i]'
    ];
    const noiseContainerSelector = [
      '[class*="review" i]',
      '[class*="feedback" i]',
      '[class*="recommend" i]',
      '[class*="seller" i]',
      '[class*="store" i]',
      '[class*="payment" i]',
      '[class*="coupon" i]',
      '[class*="promo" i]',
      '[class*="banner" i]',
      '[class*="choice" i]'
    ].join(', ');

    let scannedAliZone = false;
    for (const zoneSelector of aliMainZones) {
      document.querySelectorAll(zoneSelector).forEach(zone => {
        scannedAliZone = true;
        zone.querySelectorAll('img').forEach(img => {
          if (img.closest(noiseContainerSelector)) return;
          if (isNoiseImageElement(img)) return;
          const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || '';
          if (!src || !isAliProductImage(src)) return;
          imageSet.add(cleanImageUrl(src));
        });
      });
    }

    if (!scannedAliZone || imageSet.size < 3) {
      const mainArea = document.querySelector('main, [id*="root"], [class*="product" i], [class*="detail" i], body');
      if (mainArea) {
        mainArea.querySelectorAll('img').forEach(img => {
          if (img.closest(noiseContainerSelector)) return;
          if (isNoiseImageElement(img)) return;
          const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || '';
          if (!src || !isAliProductImage(src)) return;
          imageSet.add(cleanImageUrl(src));
        });
      }
    }

    // Source 6: Images dans les attributs data-src des divs (lazy-load moderne)
    document.querySelectorAll('[data-src*="alicdn"], [data-original*="alicdn"]').forEach(el => {
      const src = el.getAttribute('data-src') || el.getAttribute('data-original') || '';
      if (src && !isNoiseImage(src) && isAliProductImage(src)) {
        imageSet.add(cleanImageUrl(src));
      }
    });

    // Dédouper par nom de fichier (même image, résolutions différentes)
    const rawGallery = deduplicateImages(Array.from(imageSet));
    data.gallery = rawGallery.length > 0 ? rawGallery.slice(0, 20) : pageState.gallery.slice(0, 20);
    data.image = data.gallery[0];
    console.log('[IT Vision] Images galerie trouvées:', data.gallery.length);

    // ===== VIDÉOS =====
    try {
      data.videos = extractVideos(document);
      // Aussi chercher dans les JSON embarqués AliExpress
      document.querySelectorAll('script:not([src])').forEach(s => {
        const txt = s.textContent || '';
        // AliExpress stocke souvent la vidéo dans "videoId" + "videoUrl"
        const m = txt.match(/"videoUrl"\s*:\s*"(https?:\/\/[^"]+\.mp4[^"]*)"/);
        if (m && m[1] && !data.videos.includes(m[1])) data.videos.push(m[1]);
      });
      console.log('[IT Vision] AliExpress Vidéos:', data.videos.length);
    } catch { data.videos = []; }

    // ===== RATING & COMMANDES =====
    try {
      // Chercher pattern "4.8" dans les éléments de rating
      const bodyText = document.body.innerText.slice(0, 5000);
      const ratingMatch = bodyText.match(/(\d\.\d)\s*(?:\/\s*5|stars?|étoiles?|\()/i);
      if (ratingMatch) data.rating = parseFloat(ratingMatch[1]);
      
      const ordersMatch = bodyText.match(/(\d[\d,. ]*)\s*(?:sold|vendu|command|order)/i);
      if (ordersMatch) data.orders = parseInt(ordersMatch[1].replace(/[^\d]/g, ''));
    } catch {}

    // ===== TROUVER LES SECTIONS PAR TEXTE DES HEADINGS =====
    // AliExpress fr: les sections sont identifiées par leur heading textuel
    // "Détails" → tableau clé-valeur  |  "Présentation" → Caractéristiques + Spécifications
    
    // Helper: trouver une section par le texte de son heading
    const findSectionByHeading = (keywords) => {
      // Chercher dans h1-h6, strong, b, span, div qui contiennent un des keywords
      const allHeadings = document.querySelectorAll('h1, h2, h3, h4, h5, h6, strong, b, [class*="title" i], [class*="Title" i], [class*="heading" i]');
      for (const h of allHeadings) {
        const text = h.textContent?.trim().toLowerCase() || '';
        if (keywords.some(k => text === k || text.startsWith(k))) {
          // Remonter au parent conteneur (la section qui contient ce heading)
          let section = h.parentElement;
          // Remonter jusqu'à trouver un conteneur assez large
          for (let i = 0; i < 5 && section; i++) {
            if (section.innerText && section.innerText.length > text.length + 50) {
              return section;
            }
            section = section.parentElement;
          }
          return h.parentElement;
        }
      }
      return null;
    };

    // Cliquer sur "Voir plus" / "Voir tout" s'il existe
    try {
      document.querySelectorAll('button, a, span, div').forEach(el => {
        const text = (el.textContent || '').trim().toLowerCase();
        if ((text.includes('voir plus') || text.includes('voir tout') || text.includes('see more') || text.includes('view more'))
            && text.length < 30) {
          el.click();
          console.log('[IT Vision] Bouton cliqué:', text);
        }
      });
      await wait(1000);
    } catch {}

    // ===== SECTION "DÉTAILS" (tableau clé-valeur) =====
    const specs = {};

    // Filtrage: exclure les specs dont la clé est un nombre, trop courte, ou inutile
    const isUsefulSpecKey = (key) => {
      if (!key || key.length < 2 || key.length > 60) return false;
      // Exclure si la clé est un nombre pur (ex: "4", "1080")
      if (/^\d+([.,]\d+)?$/.test(key.trim())) return false;
      // Exclure des clés connues pour être du bruit
      const noise = ['sku', 'model number', 'item specifics', 'n/a', 'non spécifié',
        'produit chimique', 'remplacement', 'cn (origine)', 'cn'];
      if (noise.some(n => key.toLowerCase().includes(n))) return false;
      return true;
    };

    const isUsefulSpecValue = (val) => {
      if (!val || val.length === 0 || val.length > 200) return false;
      const lower = val.toLowerCase();
      if (lower === 'n/a' || lower === 'non spécifié' || lower === 'none' || lower === 'no') return false;
      return true;
    };

    try {
      const detailsSection = findSectionByHeading(['détails', 'details', 'specifications', 'spécifications']);
      if (detailsSection) {
        console.log('[IT Vision] Section Détails trouvée');
        // Extraire les lignes de tableau (td-td ou div-div pairs)
        detailsSection.querySelectorAll('tr').forEach(row => {
          const cells = row.querySelectorAll('td, th');
          if (cells.length >= 2) {
            const key = cells[0].textContent?.trim();
            const value = cells[1].textContent?.trim();
            if (isUsefulSpecKey(key) && isUsefulSpecValue(value)) {
              specs[key] = value;
            }
          }
        });
        // Aussi chercher des paires dans des div adjacents
        if (Object.keys(specs).length === 0) {
          const allText = detailsSection.innerText || '';
          const lines = allText.split('\n').map(l => l.trim()).filter(l => l.length > 3);
          for (const line of lines) {
            const kvMatch = line.match(/^([^:：]+?)\s*[:\s：]\s*(.+)$/);
            if (kvMatch && isUsefulSpecKey(kvMatch[1].trim()) && isUsefulSpecValue(kvMatch[2].trim())) {
              specs[kvMatch[1].trim()] = kvMatch[2].trim();
            }
          }
        }
      }
      console.log('[IT Vision] Specs Détails:', Object.keys(specs).length);
    } catch (e) {
      console.warn('[IT Vision] Erreur extraction Détails:', e);
    }

    // ===== SECTION "PRÉSENTATION" (Caractéristiques + Spécifications + poids) =====
    let presentationText = '';
    // Images descriptives du produit (souvent dans la section présentation)
    const descriptionImages = [];
    try {
      const presSection = findSectionByHeading(['présentation', 'presentation', 'overview', 'description']);
      if (presSection) {
        console.log('[IT Vision] Section Présentation trouvée');

        // Extraire les images descriptives (souvent des infographies produit)
        presSection.querySelectorAll('img').forEach(img => {
          if (isNoiseImageElement(img)) return;
          const src = img.getAttribute('src') || img.getAttribute('data-src') || '';
          if (!src) return;
          if (!isAliProductImage(src)) return;
          descriptionImages.push(cleanImageUrl(src));
        });

        // Nettoyer le texte en excluant les sections de bruit
        // Cloner pour ne pas modifier le DOM
        const clone = presSection.cloneNode(true);

        // Supprimer les blocs de bruit connus
        const noiseSelectors = [
          '[class*="review" i]', '[class*="Review" i]', '[class*="feedback" i]',
          '[class*="rating" i]', '[class*="Rating" i]',
          '[class*="recommend" i]', '[class*="Recommend" i]',
          '[class*="also-like" i]', '[class*="AlsoLike" i]',
          '[class*="buyer" i]', '[class*="Buyer" i]',
          '[class*="seller" i]', '[class*="Seller" i]', '[class*="store-info" i]',
          '[class*="price" i]', '[class*="Price" i]',
          '[class*="coupon" i]', '[class*="Coupon" i]',
          '[class*="shipping" i]', '[class*="Shipping" i]',
          '[class*="cart" i]', '[class*="Cart" i]',
          '[class*="quantity" i]', '[class*="Quantity" i]'
        ];
        noiseSelectors.forEach(sel => {
          clone.querySelectorAll(sel).forEach(el => el.remove());
        });

        let rawText = clone.innerText?.trim() || '';

        // Supprimer les lignes de bruit par pattern
        const noisePatterns = [
          /^\d+[.,]?\d*\s*[€$£¥]/m,                      // Lignes de prix
          /^(?:Économisez|Save|Payez|Pay)\s/im,            // Offres
          /^\d+\s*(?:Avis|Reviews?|évaluations?)\b/im,     // Compteurs avis
          /^(?:Avis des acheteurs|Buyer reviews)\b/im,     // Titre section avis
          /^(?:Vous aimerez aussi|You may also like)\b/im, // Recommandations
          /^(?:Trier par|Sort by)\b/im,                    // Contrôles tri
          /^(?:Toutes les notes|All ratings)\b/im,         // Filtres avis
          /^\(\d+\)$/m,                                    // Compteurs entre parenthèses
          /^(?:Color|Couleur|Taille|Size)\s*:/im,          // Sélecteurs variantes
          /^\d+[.,]\d+\s*(?:\/\s*5)?$/m,                  // Notes isolées
          /^(?:Est-ce utile|Is this helpful)\b/im,         // Utilité avis
          /^(?:Ce vendeur|This seller)\b/im,               // Info vendeur
          /^(?:Fin\s*:|Ends?)\s/im,                        // Dates d'expiration promo
          /^(?:Ventes? totales?|Total sales)\b/im,         // Stats vendeur
          /^Venant tous d/im,                              // "Venant tous d'achats vérifiés"
          /\bPayPal\b.*sans frais/im,                      // Paiement
          /^-?\d+[.,]\d+\s*[€$£]\s*(sur|on)\s/im,        // Réductions
          /^-\d+%\s*suppl/im,                              // Réductions supplémentaires
          /^\w[*]+\w\s*\|/m,                               // Noms masqués d'avis (c***r |)
          /^\d{2}\s+(?:janv|févr|mars|avr|mai|juin|juil|août|sept|oct|nov|déc)/im, // Dates d'avis
          /^\d{2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/im
        ];

        const cleanedLines = rawText.split('\n')
          .map(l => l.trim())
          .filter(l => {
            if (l.length < 3) return false;
            for (const pattern of noisePatterns) {
              if (pattern.test(l)) return false;
            }
            return true;
          });

        presentationText = cleanedLines.join('\n')
          .replace(/\n{3,}/g, '\n\n')
          .replace(/\t/g, ' ')
          .slice(0, 5000)
          .trim();
      }
      
      // Fallback: chercher "Caractéristiques" ou "Spécifications" directement
      if (!presentationText || presentationText.length < 50) {
        const caracSection = findSectionByHeading(['caractéristiques', 'caractéristiques :', 'features']);
        if (caracSection) {
          presentationText = caracSection.innerText?.trim().slice(0, 5000) || '';
        }
      }

      console.log('[IT Vision] Présentation:', presentationText.length, 'chars');
      console.log('[IT Vision] Images description:', descriptionImages.length);
    } catch (e) {
      console.warn('[IT Vision] Erreur extraction Présentation:', e);
    }

    // ===== POIDS & DIMENSIONS (depuis Présentation + Détails + page entière) =====
    let weightKg = 0;
    let lengthCm = 0, widthCm = 0, heightCm = 0;
    try {
      // Texte combiné à chercher (Présentation d'abord, puis page entière)
      const searchTexts = [presentationText, document.body.innerText].filter(t => t.length > 0);
      
      for (const searchText of searchTexts) {
        if (weightKg > 0 && lengthCm > 0) break; // Déjà trouvé

        // === POIDS ===
        if (weightKg === 0) {
          const weightPatterns = [
            /(?:poids\s*(?:du\s*)?(?:colis|paquet|emballage|package|brut|net|produit|article))\s*[:\s：]+\s*(\d+(?:[.,]\d+)?)\s*(kg|g|lb|oz)/i,
            /(?:package\s*weight|gross\s*weight|net\s*weight|item\s*weight|product\s*weight)\s*[:\s：]+\s*(\d+(?:[.,]\d+)?)\s*(kg|g|lb|oz)/i,
            /(?:weight|poids)\s*[:\s：]+\s*(\d+(?:[.,]\d+)?)\s*(kg|g|lb|oz)/i,
            /(\d+(?:[.,]\d+)?)\s*(kg|g)\b/i,
          ];
          for (const pattern of weightPatterns) {
            const m = searchText.match(pattern);
            if (m) {
              const val = parseFloat(m[1].replace(',', '.'));
              const unit = m[2].toLowerCase();
              if (unit === 'kg' && val > 0 && val < 500) weightKg = val;
              else if (unit === 'g' && val > 0) weightKg = val / 1000;
              else if (unit === 'lb') weightKg = val * 0.4536;
              else if (unit === 'oz') weightKg = val * 0.02835;
              if (weightKg > 0) {
                console.log('[IT Vision] Poids trouvé:', weightKg, 'kg');
                break;
              }
            }
          }
        }

        // === DIMENSIONS ===
        if (lengthCm === 0) {
          const dimPatterns = [
            /(?:taille|dimensions?|size|package\s*size)\s*[:\s：]+\s*(?:environ\s*)?(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*(cm|mm|inch|in|m\b)/i,
            /(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)\s*(cm|mm|inch|in)\b/i,
          ];
          for (const pattern of dimPatterns) {
            const m = searchText.match(pattern);
            if (m) {
              let l = parseFloat(m[1].replace(',', '.'));
              let w = parseFloat(m[2].replace(',', '.'));
              let h = parseFloat(m[3].replace(',', '.'));
              const unit = m[4].toLowerCase();
              if (unit === 'mm') { l /= 10; w /= 10; h /= 10; }
              else if (unit === 'inch' || unit === 'in') { l *= 2.54; w *= 2.54; h *= 2.54; }
              else if (unit === 'm' && l < 10) { l *= 100; w *= 100; h *= 100; }
              if (l > 0 && w > 0 && h > 0 && l < 500 && w < 500 && h < 500) {
                lengthCm = Math.round(l * 10) / 10;
                widthCm = Math.round(w * 10) / 10;
                heightCm = Math.round(h * 10) / 10;
                console.log('[IT Vision] Dimensions trouvées:', lengthCm, 'x', widthCm, 'x', heightCm, 'cm');
                break;
              }
            }
          }
        }
      }

      // Chercher aussi dans les specs du tableau Détails
      if (weightKg === 0 || lengthCm === 0) {
        for (const [key, value] of Object.entries(specs)) {
          const k = key.toLowerCase();
          if (weightKg === 0 && (k.includes('weight') || k.includes('poids'))) {
            const wm = String(value).match(/(\d+(?:[.,]\d+)?)\s*(kg|g|lb)/i);
            if (wm) {
              const val = parseFloat(wm[1].replace(',', '.'));
              if (wm[2].toLowerCase() === 'kg') weightKg = val;
              else if (wm[2].toLowerCase() === 'g') weightKg = val / 1000;
              else if (wm[2].toLowerCase() === 'lb') weightKg = val * 0.4536;
            }
          }
          if (lengthCm === 0 && (k.includes('size') || k.includes('dimension') || k.includes('taille'))) {
            const dm = String(value).match(/(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)/);
            if (dm) {
              lengthCm = parseFloat(dm[1].replace(',', '.'));
              widthCm = parseFloat(dm[2].replace(',', '.'));
              heightCm = parseFloat(dm[3].replace(',', '.'));
            }
          }
        }
      }

      console.log('[IT Vision] Final — Poids:', weightKg, 'kg | Dim:', lengthCm, 'x', widthCm, 'x', heightCm, 'cm');
    } catch (e) {
      console.warn('[IT Vision] Erreur extraction poids/dimensions:', e);
    }

    // ===== DESCRIPTION NETTOYÉE ET STRUCTURÉE =====
    try {
      const descParts = [];

      // Partie 1: Titre produit formaté
      if (data.name) {
        descParts.push(`# ${data.name}`);
      }

      // Partie 2: Tableau Détails (specs filtrées)
      const usefulSpecs = Object.entries(specs)
        .filter(([k, v]) => isUsefulSpecKey(k) && isUsefulSpecValue(v));

      if (usefulSpecs.length > 0) {
        descParts.push('\n## Caractéristiques techniques');
        for (const [k, v] of usefulSpecs.slice(0, 20)) {
          descParts.push(`- **${k}**: ${v}`);
        }
      }

      // Partie 3: Présentation (déjà nettoyée des avis/prix/bruit)
      if (presentationText && presentationText.length > 30) {
        let cleanText = presentationText
          .replace(/\n{3,}/g, '\n\n')
          .replace(/\t/g, ' ')
          .replace(/\s{2,}/g, ' ')
          .trim();

        // Découper en paragraphes et filtrer les très courts
        const paragraphs = cleanText.split('\n\n')
          .filter(p => p.trim().length > 15)
          .slice(0, 5);

        if (paragraphs.length > 0) {
          descParts.push('\n## Description');
          paragraphs.forEach(p => descParts.push(p.trim()));
        }
      }

      // Partie 4: Notes compactes (pas d'infos boutique)
      if (data.rating) {
        descParts.push(`\n> Note: ${data.rating}/5${data.orders ? ` — ${data.orders} commandes` : ''}`);
      }

      // Assembler la description finale
      if (descParts.length > 0) {
        let finalDesc = descParts.join('\n\n');
        if (finalDesc.length > 4500) {
          finalDesc = finalDesc.slice(0, 4500) + '...';
        }
        data.description = finalDesc.trim();
      }

      // Fallback: JSON-LD description
      if (!data.description && jsonLdProduct?.description) {
        data.description = jsonLdProduct.description.trim().slice(0, 2000);
      }

      // Fallback: meta description
      if (!data.description) {
        const metaDesc = document.querySelector('meta[name="description"]')?.getAttribute('content')
          || document.querySelector('meta[property="og:description"]')?.getAttribute('content');
        if (metaDesc && metaDesc.length > 20) {
          data.description = metaDesc.trim();
        }
      }

      console.log('[IT Vision] Description finale:', data.description?.length || 0, 'chars');
    } catch (e) {
      console.warn('[IT Vision] Erreur description:', e);
    }

    // ===== VARIANTES (groupées par type: Couleur, Taille, etc.) =====
    try {
      data.variantGroups = [];

      // Normaliser les noms de groupes vers le français
      const normalizeGroupName = (raw) => {
        const s = raw.trim().replace(/[:\s：]+$/, '').replace(/\s*:\s*.*$/, '').trim();
        const lower = s.toLowerCase();
        // Couleur
        if (/^colou?r|^couleur|^farbe/i.test(lower)) return 'Couleur';
        if (lower === 'color' || lower === 'colour' || lower === 'colors') return 'Couleur';
        // Taille
        if (/^size|^taille|^größe/i.test(lower)) return 'Taille';
        if (lower === 'shoe size' || lower === 'shoe us size' || lower === 'us size' || lower === 'eu size') return 'Taille';
        // Autres connus
        if (/^capacit/i.test(lower)) return 'Capacité';
        if (/^style/i.test(lower)) return 'Style';
        if (/^mod[eè]le|^model/i.test(lower)) return 'Modèle';
        if (/^type/i.test(lower)) return 'Type';
        if (/^quantit/i.test(lower)) return 'Quantité';
        if (/^mat[eéi]/i.test(lower)) return 'Matière';
        if (/^plug|^prise/i.test(lower)) return 'Prise';
        if (/^puissance|^watt|^power/i.test(lower)) return 'Puissance';
        if (/^longueur|^length/i.test(lower)) return 'Longueur';
        if (s.length >= 2 && s.length <= 25) return s;
        return '';
      };

      // Vérifier qu'un nom de variante est valide (pas du bruit)
      const isValidVariantName = (name, groupName) => {
        if (!name || name.length < 1 || name.length > 80) return false;
        // Exclure le label du groupe lui-même
        if (name === groupName || name.toLowerCase() === groupName.toLowerCase()) return false;
        // Exclure les textes qui ressemblent à du bruit UI
        if (/^(acheter|buy|ajouter|add|partager|share|signaler|report|voir|see|ok|non|oui)/i.test(name)) return false;
        if (/[:\s：]{2,}/.test(name)) return false;
        // Exclure les prix isolés
        if (/^[€$£¥￥]\s*\d/.test(name) || /^\d+[.,]\d+\s*[€$£¥￥]$/.test(name)) return false;
        // Exclure les compteurs / pourcentages
        if (/^\d+\s*(%|avis|reviews?|commandes?|sold|vendu)$/i.test(name)) return false;
        // Exclure les textes trop longs qui contiennent des retours à la ligne
        if (name.includes('\n') || name.includes('\r')) return false;
        return true;
      };

      const processedLabels = new Set();

      // ── Méthode 1: Conteneurs de propriétés SKU structurés ──
      // AliExpress utilise des conteneurs avec des classes spécifiques pour chaque groupe de variantes
      const skuContainers = document.querySelectorAll(
        '[class*="sku-property" i], [class*="skuProperty" i], [class*="sku--property" i], ' +
        '[class*="product-sku" i], [class*="productSku" i], ' +
        '[class*="sku-item-property" i], [data-sku-col], ' +
        '[class*="property-item" i]:not([class*="property-item-value" i])'
      );

      // Si les sélecteurs spécifiques ne trouvent rien, fallback sur les sélecteurs plus larges
      const containers = skuContainers.length > 0 ? skuContainers
        : document.querySelectorAll('[class*="sku" i][class*="prop" i], [class*="variant" i][class*="group" i]');

      containers.forEach(container => {
        // Trouver le label du groupe
        const labelEl = container.querySelector(
          '[class*="title" i], [class*="label" i], [class*="name" i]:not(img), ' +
          '[class*="header" i], dt, h4, h5'
        );
        if (!labelEl) return;

        const rawLabel = labelEl.textContent?.trim() || '';
        const groupName = normalizeGroupName(rawLabel);
        if (!groupName || processedLabels.has(groupName)) return;

        const variants = [];
        const seenNames = new Set();

        // 1) Images avec alt (typique pour les couleurs)
        container.querySelectorAll('img[alt], img[title]').forEach(img => {
          let src = img.getAttribute('src') || img.getAttribute('data-src') || '';
          if (src.startsWith('//')) src = 'https:' + src;
          // Ignorer les icônes minuscules et placeholders
          if (src.includes('placeholder') || src.includes('data:image')) return;
          const name = (img.getAttribute('alt') || img.getAttribute('title') || '').trim();
          const cleanName = name.replace(/\s*#\d+$/, '').trim();
          if (!cleanName || seenNames.has(cleanName.toLowerCase())) return;
          if (!isValidVariantName(cleanName, groupName)) return;

          seenNames.add(cleanName.toLowerCase());
          const hdSrc = src.replace(/_\d+x\d+[^.]*/, '');
          variants.push({
            id: `v-${variants.length}`,
            name: cleanName,
            image: hdSrc || undefined,
            isDefault: variants.length === 0
          });
        });

        // 2) Options textuelles (boutons, spans cliquables) — seulement ceux directement dans le conteneur d'items
        const itemEls = container.querySelectorAll(
          '[class*="item" i] > span, [class*="item" i] > div, ' +
          '[class*="option" i], [class*="value" i], ' +
          'button > span, [role="button"] > span, [role="radio"]'
        );
        itemEls.forEach(item => {
          // Prendre seulement le texte direct, pas les enfants profonds
          let name = '';
          if (item.childNodes.length <= 3) {
            name = item.textContent?.trim() || '';
          } else {
            // Si beaucoup d'enfants, c'est probablement un conteneur, prendre le premier noeud texte
            for (const child of item.childNodes) {
              if (child.nodeType === 3 && child.textContent?.trim()) {
                name = child.textContent.trim();
                break;
              }
            }
          }

          if (!name || seenNames.has(name.toLowerCase())) return;
          if (!isValidVariantName(name, groupName)) return;
          // Ignorer si c'est un sous-texte du label
          if (rawLabel.includes(name)) return;

          seenNames.add(name.toLowerCase());
          const img = item.closest('[class*="item" i], [class*="option" i]')?.querySelector('img');
          let imgUrl = img?.getAttribute('src') || img?.getAttribute('data-src') || undefined;
          if (imgUrl?.startsWith('//')) imgUrl = 'https:' + imgUrl;
          if (imgUrl) imgUrl = imgUrl.replace(/_\d+x\d+[^.]*/, '');

          variants.push({
            id: `v-${variants.length}`,
            name,
            image: imgUrl,
            isDefault: variants.length === 0
          });
        });

        if (variants.length >= 1) {
          processedLabels.add(groupName);
          data.variantGroups.push({ name: groupName, variants });
          console.log('[IT Vision] Variante groupe:', groupName, '→', variants.length, 'options');
        }
      });

      // ── Méthode 2: Fallback — JSON embarqué dans la page (AliExpress stocke souvent les SKU en JSON) ──
      if (data.variantGroups.length === 0) {
        const scripts = document.querySelectorAll('script:not([src])');
        for (const script of scripts) {
          const text = script.textContent || '';
          // Chercher des patterns JSON de propriétés SKU
          const skuMatch = text.match(/"skuPropertyList"\s*:\s*(\[[\s\S]*?\])\s*[,}]/);
          if (skuMatch) {
            try {
              const skuList = JSON.parse(skuMatch[1]);
              for (const group of skuList) {
                const groupName = normalizeGroupName(group.skuPropertyName || group.name || '');
                if (!groupName || processedLabels.has(groupName)) continue;
                const values = group.skuPropertyValues || group.values || [];
                if (!Array.isArray(values) || values.length === 0) continue;
                const variants = values.map((v, idx) => ({
                  id: `v-${idx}`,
                  name: (v.propertyValueDisplayName || v.name || v.propertyValueName || '').trim(),
                  image: v.skuPropertyImagePath || v.image || undefined,
                  isDefault: idx === 0
                })).filter(v => v.name && isValidVariantName(v.name, groupName));
                if (variants.length >= 1) {
                  processedLabels.add(groupName);
                  data.variantGroups.push({ name: groupName, variants });
                  console.log('[IT Vision] Variante JSON:', groupName, '→', variants.length);
                }
              }
            } catch (e) { /* JSON parse error, skip */ }
            if (data.variantGroups.length > 0) break;
          }
        }
      }

      // JSON de la page : prix et stock par déclinaison, image par option
      const scriptGroups = extractVariantsFromScripts();
      if (scriptGroups.length) data.variantGroups = mergeVariantGroups(scriptGroups, data.variantGroups);

      console.log('[IT Vision] Total groupes de variantes:', data.variantGroups.length,
        data.variantGroups.map(g => `${g.name}(${g.variants.length})`).join(', '));
    } catch (e) {
      console.warn('[IT Vision] Erreur extraction variantes:', e);
    }

    // ===== CLASSIFICATION DES IMAGES =====
    // Collecter les images de variantes depuis les variantGroups
    const variantImages = [];
    (data.variantGroups || []).forEach(g => {
      (g.variants || []).forEach(v => {
        if (v.image && !variantImages.includes(v.image)) variantImages.push(v.image);
      });
    });

    // Séparer packaging des images de description
    const cleanDescImages = [];
    const packagingImages = [];
    descriptionImages.forEach(url => {
      const lower = url.toLowerCase();
      if (/packag|box|carton|emball|colis/i.test(lower)) {
        packagingImages.push(url);
      } else {
        cleanDescImages.push(url);
      }
    });

    data.descriptionImages = deduplicateImages(cleanDescImages).length > 0
      ? deduplicateImages(cleanDescImages).slice(0, 30)
      : pageState.descriptionImages.slice(0, 30);

    data.imageCategories = {
      main: data.gallery.slice(0, 1),
      gallery: data.gallery,
      variant: deduplicateImages(variantImages).slice(0, 20),
      description: data.descriptionImages,
      packaging: deduplicateImages(packagingImages).slice(0, 5)
    };

    console.log('[IT Vision] Images classées:', {
      galerie: data.gallery.length,
      variantes: variantImages.length,
      description: data.descriptionImages.length,
      packaging: packagingImages.length
    });

    // Classement final des images (données JSON de la page + DOM)
    try { finalizeImages(data); } catch (e) { console.warn('[IT Vision] Classement images AliExpress:', e); }

    // Features (résumé compact)
    data.features = [
      data.rating && `Note: ${data.rating}/5`,
      data.orders && `${data.orders} commandes`,
      data.gallery.length > 0 && `${data.gallery.length} images galerie`,
      data.descriptionImages.length > 0 && `${data.descriptionImages.length} images description`,
      data.videos?.length > 0 && `${data.videos.length} vidéo(s)`,
      weightKg > 0 && `Poids: ${weightKg} kg`,
      (lengthCm > 0) && `Dimensions: ${lengthCm}×${widthCm}×${heightCm} cm`,
      Object.keys(specs).length > 0 && `${Object.keys(specs).length} spécifications`,
      data.variantGroups?.length > 0 && `${data.variantGroups.length} types de variantes`
    ].filter(Boolean);

    // Données logistiques
    data.specifications = Object.keys(specs).length > 0 ? specs : (pageState.specifications || {});
    if (Object.keys(data.specifications).length === 0) data.specifications = {};
    data.weightKg = weightKg > 0 ? weightKg : (pageState.weightKg || undefined);
    data.lengthCm = lengthCm > 0 ? lengthCm : (pageState.lengthCm || undefined);
    data.widthCm = widthCm > 0 ? widthCm : (pageState.widthCm || undefined);
    data.heightCm = heightCm > 0 ? heightCm : (pageState.heightCm || undefined);
    if (pageState.shopName && !data.shopName) data.shopName = pageState.shopName;

    // Valeurs par défaut
    data.category = classifyCategory(data.name, data.description, data.specifications) || 'Catalogue import Chine';
    data.tagline = 'Import AliExpress';
    data.availabilityNote = 'Import AliExpress - freight 3j/15j/60j';
    data.currency = 'FCFA';

    console.log('[IT Vision] AliExpress extrait:', {
      name: data.name,
      price: data.price,
      gallery: data.gallery?.length,
      descImages: data.descriptionImages?.length,
      videos: data.videos?.length,
      variants: data.variantGroups?.length,
      specs: Object.keys(specs).length,
      weight: weightKg
    });
    return data;
  };

  // ==========================================
  // EXTRACTEUR ALIBABA (alibaba.com et sous-domaines : fr., es., …)
  // ==========================================

  /** « 1,234.56 » / « 1 234,56 » / « 3.5 » → nombre */
  const parseLocaleAmount = (raw) => {
    let s = String(raw || '').replace(/[\s\u00a0\u202f]/g, '');
    if (!s) return NaN;
    const lastComma = s.lastIndexOf(','), lastDot = s.lastIndexOf('.');
    if (lastComma > -1 && lastDot > -1) {
      s = lastComma > lastDot ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    } else if (lastComma > -1) {
      s = /,\d{1,2}$/.test(s) ? s.replace(',', '.') : s.replace(/,/g, '');
    }
    return parseFloat(s);
  };

  const ALIBABA_UNIT_RE = '(?:pieces?|pcs|sets?|units?|pairs?|boxes|cartons?|meters?|kilograms?|kg|bags?|rolls?|pi[eè]ces?|unit[eé]s?|ensembles?|paires?|bo[iî]tes?|m[eè]tres?|lots?)';

  const scrapeAlibaba = async () => {
    console.log('[IT Vision] Extraction Alibaba...');
    const data = {
      platform: 'alibaba',
      url: window.location.href.split('?')[0],
      timestamp: new Date().toISOString(),
      gallery: [],
      descriptionImages: [],
      videos: [],
      variantGroups: [],
      features: [],
      specifications: {},
    };

    try {
      await wait(1500);
      await deepScroll(7000, 450, 220);
    } catch (e) { console.warn('[IT Vision] Scroll Alibaba:', e); }

    const bodyText = document.body?.innerText || '';

    // ── TITRE ──
    data.name = trySelectors([
      'h1[class*="title" i]', '[class*="product-title" i] h1', '[class*="product-title" i]',
      '[class*="module-pdp-title" i] h1', '[data-module-name*="title" i] h1', 'h1',
    ]) || document.querySelector('meta[property="og:title"]')?.getAttribute('content')?.trim()
      || document.title.replace(/\s*[-|].*$/, '').trim() || 'Produit Alibaba';

    // ── PRIX + PALIERS (USD sur alibaba.com, EUR possible sur fr.alibaba.com) ──
    try {
      const priceArea = document.querySelector('[class*="product-price" i], [class*="price-list" i], [class*="price-wrap" i], [class*="module-pdp-price" i], [data-module-name*="price" i]');
      const priceText = (priceArea?.innerText || bodyText.slice(0, 8000));
      data.price1688Currency = /€|EUR/.test(priceText) ? 'EUR' : 'USD';

      const tiers = [];
      const tierRe = new RegExp(`(?:≥|>=|\\+)?\\s*([\\d][\\d\\s.,]*)\\s*(?:-\\s*([\\d][\\d\\s.,]*))?\\s*${ALIBABA_UNIT_RE}[^\\d$€]{0,20}(?:US\\s?\\$|\\$|€|EUR|USD)?\\s*(\\d[\\d.,]*)\\s*(?:€|EUR)?`, 'gi');
      document.querySelectorAll('[class*="price-item" i], [class*="ladder" i] [class*="item" i], [class*="price-list" i] > *, [class*="price-range" i] > *').forEach(item => {
        const text = (item.innerText || '').replace(/\n+/g, ' ');
        tierRe.lastIndex = 0;
        const m = tierRe.exec(text);
        if (!m) return;
        const minQty = parseInt(m[1].replace(/\D/g, ''), 10);
        const maxQty = m[2] ? parseInt(m[2].replace(/\D/g, ''), 10) : undefined;
        const price = parseLocaleAmount(m[3]);
        if (minQty > 0 && price > 0 && !tiers.some(t => t.minQty === minQty)) tiers.push({ minQty, maxQty, price1688: price });
      });

      if (tiers.length) {
        tiers.sort((a, b) => a.minQty - b.minQty);
        data.priceTiers = tiers;
        // Prix de référence : celui de la quantité minimale (le plus élevé, le plus prudent)
        data.price1688 = tiers[0].price1688;
        data.moq = data.moq || tiers[0].minQty;
      } else {
        const m = priceText.match(/(?:US\s?\$|\$|€)\s*(\d[\d.,]*)(?:\s*-\s*(?:US\s?\$|\$|€)?\s*(\d[\d.,]*))?|(\d[\d.,]*)\s*€/);
        const values = m ? [m[1], m[2], m[3]].map(parseLocaleAmount).filter(v => v > 0) : [];
        if (values.length) data.price1688 = Math.max(...values);
      }
    } catch (e) { console.warn('[IT Vision] Prix Alibaba:', e); }

    // ── MOQ ──
    try {
      const m = bodyText.match(new RegExp(`(?:min\\.?\\s*order|minimum order(?: quantity)?|commande minimale|quantit[ée] minimale|qt[ée]\\.? min\\.?)\\s*:?\\s*([\\d][\\d\\s.,]*)\\s*${ALIBABA_UNIT_RE}?`, 'i'));
      const moq = m ? parseInt(m[1].replace(/\D/g, ''), 10) : 0;
      if (moq > 0) data.moq = moq;
    } catch {}

    // ── IMAGES (DOM ; complétées par les données JSON dans finalizeImages) ──
    try {
      const imageSet = new Set();
      const gallerySelectors = [
        '[class*="image-list" i] img', '[class*="main-image" i] img', '[class*="gallery" i] img',
        '[class*="slider" i] img', '[class*="detail-image" i] img', '[class*="media-item" i] img',
        '[class*="thumb" i] img', '[data-module-name*="gallery" i] img',
      ];
      gallerySelectors.forEach(sel => document.querySelectorAll(sel).forEach(img => {
        if (img.closest('[class*="description" i], [id*="description" i], [class*="recommend" i], [class*="supplier" i]')) return;
        const src = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('src') || '';
        if (!src || isNoiseImageElement(img) || !isAlibabaProductImage(src)) return;
        const clean = cleanImageUrl(src);
        if (clean) imageSet.add(clean);
      }));
      document.querySelectorAll('[class*="gallery" i] [style*="background-image"], [class*="image-list" i] [style*="background-image"]').forEach(el => {
        const m = (el.getAttribute('style') || '').match(/url\(["']?([^"')]+)["']?\)/);
        if (m && isAlibabaProductImage(m[1]) && !isNoiseImage(m[1])) imageSet.add(cleanImageUrl(m[1]));
      });
      data.gallery = Array.from(imageSet);
    } catch (e) { console.warn('[IT Vision] Images Alibaba:', e); }

    // ── VIDÉOS ──
    try { data.videos = extractVideos(document); } catch { data.videos = []; }

    // ── SPÉCIFICATIONS (attributs clés) ──
    try {
      const specs = {};
      const addSpec = (k, v) => {
        const key = (k || '').replace(/[:：]\s*$/, '').trim();
        const val = (v || '').trim();
        if (key && val && key.length <= 60 && val.length <= 200 && key !== val && !specs[key]) specs[key] = val;
      };
      document.querySelectorAll('[class*="attribute" i] [class*="item" i], [class*="attr-list" i] > *, [class*="specification" i] [class*="item" i], [class*="key-attr" i] [class*="item" i]').forEach(item => {
        const kEl = item.querySelector('[class*="name" i], [class*="label" i], [class*="key" i], dt, th');
        const vEl = item.querySelector('[class*="value" i], [class*="info" i], dd, td');
        if (kEl && vEl) addSpec(kEl.innerText, vEl.innerText);
      });
      document.querySelectorAll('[class*="attribute" i] tr, [class*="specification" i] tr, [class*="detail-attr" i] tr').forEach(tr => {
        const cells = tr.querySelectorAll('td, th');
        for (let i = 0; i + 1 < cells.length; i += 2) addSpec(cells[i].innerText, cells[i + 1].innerText);
      });
      document.querySelectorAll('[class*="attribute" i] dl, [class*="specification" i] dl').forEach(dl => {
        const dts = dl.querySelectorAll('dt');
        dts.forEach(dt => addSpec(dt.innerText, dt.nextElementSibling?.innerText));
      });
      data.specifications = specs;
    } catch (e) { console.warn('[IT Vision] Spécifications Alibaba:', e); }

    // ── VARIANTES (couleur, taille, modèle…) ──
    try {
      const groups = [];
      document.querySelectorAll('[class*="sku-item" i], [class*="sku-prop" i], [class*="sku-attr" i], [class*="sku-info" i] > *, [data-module-name*="sku" i] [class*="item" i]').forEach(container => {
        const labelEl = container.querySelector('[class*="title" i], [class*="label" i], [class*="name" i], dt, h4, h5, strong');
        let groupName = (labelEl?.innerText || '').replace(/[:：].*$/s, '').replace(/\(\d+\)/, '').trim();
        if (!groupName || groupName.length > 40) return;
        if (/colou?r|couleur|color/i.test(groupName)) groupName = 'Couleur';
        else if (/size|taille|dimension/i.test(groupName)) groupName = 'Taille';
        else if (/model|mod[eè]le|style|type/i.test(groupName)) groupName = 'Modèle';
        if (groups.some(g => g.name === groupName)) return;

        const variants = [];
        container.querySelectorAll('[class*="value" i] > *, [class*="option" i], [class*="sku-item-image" i], li, img').forEach((item, idx) => {
          if (item === labelEl || item.contains(labelEl)) return;
          const img = item.tagName === 'IMG' ? item : item.querySelector('img');
          const name = (item.getAttribute('title') || img?.getAttribute('alt') || img?.getAttribute('title') || item.innerText || '').trim();
          if (!name || name.length > 80 || name === groupName || variants.some(v => v.name === name)) return;
          const src = img ? (img.getAttribute('data-src') || img.getAttribute('src') || '') : '';
          variants.push({
            id: `sku-${groups.length}-${idx}`,
            name,
            image: src ? cleanImageUrl(src) || undefined : undefined,
            price1688: data.price1688,
            stock: 1000,
            isDefault: variants.length === 0,
          });
        });
        if (variants.length > 1) groups.push({ name: groupName, variants });
      });
      data.variantGroups = groups;

      // JSON de la page : image, prix et stock par option ; le DOM reste le repli
      const scriptGroups = extractVariantsFromScripts();
      if (scriptGroups.length) data.variantGroups = mergeVariantGroups(scriptGroups, data.variantGroups);
      console.log('[IT Vision] Alibaba Variantes:', data.variantGroups.map(g => `${g.name}(${g.variants.length})`).join(', ') || 'aucune');
    } catch (e) { console.warn('[IT Vision] Variantes Alibaba:', e); }

    // ── DESCRIPTION (texte + images du descriptif) ──
    let presentationText = '';
    try {
      const descRoot = document.querySelector('#description, [id*="description" i], [class*="product-description" i], [class*="detail-desc" i], [class*="description-layout" i], [data-module-name*="description" i]');
      if (descRoot) {
        presentationText = cleanTextFromElement(descRoot).slice(0, 4000);
        descRoot.querySelectorAll('img').forEach(img => {
          const src = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('src') || '';
          if (!src || isNoiseImage(src)) return;
          const clean = cleanImageUrl(src);
          if (clean && !data.descriptionImages.includes(clean)) data.descriptionImages.push(clean);
        });
      }
    } catch (e) { console.warn('[IT Vision] Description Alibaba:', e); }
    data.description = buildStructuredDescription({ title: data.name, specs: data.specifications, presentationText });

    // ── FOURNISSEUR ──
    try {
      data.shopName = trySelectors(['[class*="company-name" i]', '[class*="supplier-name" i]', '[class*="store-name" i]', 'a[href*=".en.alibaba.com"]']) || undefined;
      if (data.shopName) data.supplier = { name: data.shopName };
    } catch {}

    // ── POIDS & DIMENSIONS (section « Emballage et livraison ») ──
    try {
      const pack = bodyText.match(/(?:single package size|package size|taille (?:du|de l')?\s*(?:paquet|emballage)[^:]*)\s*:?\s*([\d.,]+)\s*[xX×*]\s*([\d.,]+)\s*[xX×*]\s*([\d.,]+)\s*cm/i);
      if (pack) {
        const [l, w, h] = [pack[1], pack[2], pack[3]].map(parseLocaleAmount);
        if (l > 0 && w > 0 && h > 0) { data.lengthCm = l; data.widthCm = w; data.heightCm = h; }
      }
      const weight = bodyText.match(/(?:single gross weight|gross weight|poids brut(?: unique)?)\s*:?\s*([\d.,]+)\s*(kg|g)\b/i);
      if (weight) {
        const value = parseLocaleAmount(weight[1]);
        if (value > 0) data.weightKg = weight[2].toLowerCase() === 'g' ? value / 1000 : value;
      }
    } catch {}

    // ── IMAGES : classement final (données JSON de la page + DOM) ──
    try { finalizeImages(data); } catch (e) { console.warn('[IT Vision] Classement images Alibaba:', e); }

    data.category = classifyCategory(data.name, data.description, data.specifications) || 'Catalogue import Chine';
    data.tagline = 'Import Alibaba';
    data.availabilityNote = 'Import Alibaba — vérifier poids/dimensions';
    data.currency = 'FCFA';
    data.features = [
      data.moq && `MOQ: ${data.moq} unités`,
      data.priceTiers?.length && `${data.priceTiers.length} paliers de prix`,
      Object.keys(data.specifications || {}).length > 0 && `${Object.keys(data.specifications).length} spécifications`,
      data.videos?.length > 0 && `${data.videos.length} vidéo(s)`,
      data.gallery?.length > 0 && `${data.gallery.length} images galerie`,
      data.descriptionImages?.length > 0 && `${data.descriptionImages.length} images description`,
      data.weightKg && `Poids: ${data.weightKg} kg`,
    ].filter(Boolean);

    console.log('[IT Vision] Alibaba extrait:', {
      name: data.name,
      price: data.price1688,
      currency: data.price1688Currency,
      gallery: data.gallery?.length,
      descImages: data.descriptionImages?.length,
      variants: data.variantGroups?.length,
    });
    return data;
  };

  /** Extracteur adapté au site courant */
  const scrapeCurrentPage = async () => {
    const host = window.location.hostname;
    const data = host.includes('1688.com') ? await scrape1688()
      : /(^|\.)alibaba\.com$/i.test(host) ? await scrapeAlibaba()
      : await scrapeAliExpress();
    try { fillPackageInfo(data); } catch (e) { console.warn('[IT Vision] Colis:', e); }
    return data;
  };

  // ==========================================
  // UI FLOATING BUTTON
  // ==========================================
  
  const createFloatingButton = () => {
    const btn = document.createElement('div');
    btn.id = 'itvision-scraper-btn';
    btn.innerHTML = `
      <div style="
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 999999;
        background: linear-gradient(135deg, #22c55e, #8b5cf6);
        color: white;
        padding: 12px 20px;
        border-radius: 50px;
        cursor: pointer;
        font-family: system-ui, sans-serif;
        font-weight: 600;
        font-size: 14px;
        box-shadow: 0 4px 15px rgba(34, 197, 94, 0.4);
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s ease;
      ">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 3v18M3 12h18"/>
        </svg>
        Importer IT Vision
      </div>
    `;
    
    btn.onclick = async () => {
      btn.style.transform = 'scale(0.95)';
      setTimeout(() => btn.style.transform = 'scale(1)', 150);
      
      try {
        const data = await scrapeCurrentPage();
        
        // Envoyer au background script
        chrome.runtime.sendMessage({
          action: 'PRODUCT_EXTRACTED',
          data: data
        });
        
        // Feedback visuel
        const name = (data.name || 'Produit').substring(0, 30);
        showNotification(`${name}... extrait! (${data.gallery?.length || 0} img)`);
      } catch (err) {
        console.error('[IT Vision] Erreur extraction:', err);
        showNotification(`❌ Erreur: ${err.message || 'extraction échouée'}`);
      }
    };
    
    document.body.appendChild(btn);
  };

  const showNotification = (message) => {
    const notif = document.createElement('div');
    notif.innerHTML = `
      <div style="
        position: fixed;
        bottom: 80px;
        right: 20px;
        z-index: 999999;
        background: #10b981;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-family: system-ui, sans-serif;
        font-size: 14px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        animation: slideIn 0.3s ease;
      ">
        ✅ ${message}
      </div>
    `;
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 3000);
  };

  // ==========================================
  // API HEADLESS / AUTOMATION
  // ==========================================

  /** Expose un point d'entrée global utilisable par Playwright/Puppeteer */
  window.itVisionScrape = async () => {
    const data = await scrapeCurrentPage();
    return data;
  };

  // ==========================================
  // LISTENERS (mode extension Chrome uniquement)
  // ==========================================

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    // Écouter messages du popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'EXTRACT_PRODUCT') {

        scrapeCurrentPage()
          .then(data => sendResponse({ success: true, data }))
          .catch(err => sendResponse({ success: false, error: err.message }));

        return true; // Async response
      }
    });

    // Injecter bouton flottant après chargement
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', createFloatingButton);
    } else {
      createFloatingButton();
    }
  }

})();
